﻿namespace LucySpa.DataAccess
{


    public partial class DSTarjetas
    {
    }
}
