﻿namespace LucySpa.DataAccess
{
}
namespace LucySpa.DataAccess
{
}
namespace LucySpa.DataAccess
{


    public partial class LucySpaDB
    {
    }
}
namespace LucySpa.DataAccess {
    
    
    public partial class LucySpaDB {
    }
}

namespace LucySpa.DataAccess.LucySpaDBTableAdapters {
    partial class vistaCitasTableAdapter
    {
    }

    partial class VistaDiseñoCuartoServicioTableAdapter
    {
    }

    partial class CuartoTableAdapter
    {
    }
    
    
    public partial class ServicioTableAdapter {
    }
}
