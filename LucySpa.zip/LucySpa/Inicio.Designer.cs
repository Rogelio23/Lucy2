﻿namespace LucySpa
{
    partial class Inicio
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange1 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange2 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange3 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange4 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange5 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tcMenu = new MetroFramework.Controls.MetroTabControl();
            this.tpEmpleados = new MetroFramework.Controls.MetroTabPage();
            this.btnReportes = new MetroFramework.Controls.MetroButton();
            this.btnBuscarEmpleado = new MetroFramework.Controls.MetroButton();
            this.tbBuscarEmpleado = new MetroFramework.Controls.MetroTextBox();
            this.btnBorrarEmpleado = new MetroFramework.Controls.MetroButton();
            this.btnModificarEmpleado = new MetroFramework.Controls.MetroButton();
            this.btnAgregarEmpleado = new MetroFramework.Controls.MetroButton();
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this.empleadoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cumpleañosDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direccionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fotografiaEmppleado = new System.Windows.Forms.DataGridViewImageColumn();
            this.vistaEmpleadoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lucySpaDB = new LucySpa.DataAccess.LucySpaDB();
            this.tpServicios = new MetroFramework.Controls.MetroTabPage();
            this.btnBuscarServicio = new MetroFramework.Controls.MetroButton();
            this.btnBorrarServicio = new MetroFramework.Controls.MetroButton();
            this.btnModificarServicio = new MetroFramework.Controls.MetroButton();
            this.tbBuscarServicio = new MetroFramework.Controls.MetroTextBox();
            this.btnGuardarEmpleado = new MetroFramework.Controls.MetroButton();
            this.dgvServicios = new System.Windows.Forms.DataGridView();
            this.servicioIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.servicioBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpTratamiento = new MetroFramework.Controls.MetroTabPage();
            this.btnmodificarTratamiento = new MetroFramework.Controls.MetroButton();
            this.btnBorrar = new MetroFramework.Controls.MetroButton();
            this.btnDetalles = new MetroFramework.Controls.MetroButton();
            this.btnVender = new MetroFramework.Controls.MetroButton();
            this.btnAgregarTratamiento = new MetroFramework.Controls.MetroButton();
            this.btnBuscarTratamiento = new MetroFramework.Controls.MetroButton();
            this.tbBsucarTratamiento = new MetroFramework.Controls.MetroTextBox();
            this.dgvTratamiento = new System.Windows.Forms.DataGridView();
            this.tratamientoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precioCatalogo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tratamientoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpClientes = new MetroFramework.Controls.MetroTabPage();
            this.btnVenderProducto = new MetroFramework.Controls.MetroButton();
            this.btnAsignarTarjeta = new MetroFramework.Controls.MetroButton();
            this.btnAgendarCita = new MetroFramework.Controls.MetroButton();
            this.btnBuscar = new MetroFramework.Controls.MetroButton();
            this.tbBuscarCliente = new MetroFramework.Controls.MetroTextBox();
            this.btnBorrarCliente = new MetroFramework.Controls.MetroButton();
            this.btnModificarCliente = new MetroFramework.Controls.MetroButton();
            this.btnAgregarCliente = new MetroFramework.Controls.MetroButton();
            this.dgvClientes = new System.Windows.Forms.DataGridView();
            this.clienteIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreCompleto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cumpleañosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direccionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fotografiaCliente = new System.Windows.Forms.DataGridViewImageColumn();
            this.vistaCLienteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cmsClientes = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tratamientosVendidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tpCitas = new MetroFramework.Controls.MetroTabPage();
            this.btnCancelarCita = new MetroFramework.Controls.MetroButton();
            this.btnPagar = new MetroFramework.Controls.MetroButton();
            this.btnAdministrar = new MetroFramework.Controls.MetroButton();
            this.mbtnBuscarCita = new MetroFramework.Controls.MetroButton();
            this.btnBorrarCita = new MetroFramework.Controls.MetroButton();
            this.btnModificarCita = new MetroFramework.Controls.MetroButton();
            this.tbBuscarCita = new MetroFramework.Controls.MetroTextBox();
            this.dgvCitas = new System.Windows.Forms.DataGridView();
            this.citaIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClienteID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomCompletoClie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomCompletoEmp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NombreServicio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefonoDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Realizado = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.vistaCitasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpAgenda = new MetroFramework.Controls.MetroTabPage();
            this.monthViewAgenda = new System.Windows.Forms.Calendar.MonthView();
            this.calendarAgenda = new System.Windows.Forms.Calendar.Calendar();
            this.tpTarjetas = new MetroFramework.Controls.MetroTabPage();
            this.tbNuevasTarjetas = new MetroFramework.Controls.MetroTextBox();
            this.tbTarjetasLibres = new MetroFramework.Controls.MetroTextBox();
            this.tbTarjetasAsignadas = new MetroFramework.Controls.MetroTextBox();
            this.tbCantidadTarjetas = new MetroFramework.Controls.MetroTextBox();
            this.tbCostoTarjetas = new MetroFramework.Controls.MetroTextBox();
            this.lblNuevaTarjetas = new MetroFramework.Controls.MetroLabel();
            this.lblTarjetasLibres = new MetroFramework.Controls.MetroLabel();
            this.lblCantidadTarjetas = new MetroFramework.Controls.MetroLabel();
            this.lblTarjetasAsignadas = new MetroFramework.Controls.MetroLabel();
            this.lblCostoTarjeta = new MetroFramework.Controls.MetroLabel();
            this.btnBuscarTarjetas = new MetroFramework.Controls.MetroButton();
            this.btnBorrarTarjeta = new MetroFramework.Controls.MetroButton();
            this.btnModificarCostoTarjeta = new MetroFramework.Controls.MetroButton();
            this.tbBuscarTarjeta = new MetroFramework.Controls.MetroTextBox();
            this.btnAgregarTarjeta = new MetroFramework.Controls.MetroButton();
            this.dgvTarjetas = new System.Windows.Forms.DataGridView();
            this.tarjetaIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreCompletoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecchaCompraDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vistaClientesConTarjetasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dSTarjetas = new LucySpa.DataAccess.DSTarjetas();
            this.tpProductos = new MetroFramework.Controls.MetroTabPage();
            this.btnBuscarProducto = new MetroFramework.Controls.MetroButton();
            this.btnBorrarProductos = new MetroFramework.Controls.MetroButton();
            this.btnModificarProductos = new MetroFramework.Controls.MetroButton();
            this.tbBuscarProductos = new MetroFramework.Controls.MetroTextBox();
            this.btnAgregarProductos = new MetroFramework.Controls.MetroButton();
            this.dgvProductos = new System.Windows.Forms.DataGridView();
            this.productoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.precioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costoDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cantidadDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpCuartos = new MetroFramework.Controls.MetroTabPage();
            this.btnRelacionCuartoServicios = new MetroFramework.Controls.MetroButton();
            this.btnModificar = new MetroFramework.Controls.MetroButton();
            this.btnBuscarCuarto = new MetroFramework.Controls.MetroButton();
            this.btnNuevoCuarto = new MetroFramework.Controls.MetroButton();
            this.btnBorrarCuarto = new MetroFramework.Controls.MetroButton();
            this.tbBuscarCuarto = new MetroFramework.Controls.MetroTextBox();
            this.dgvCuartos = new System.Windows.Forms.DataGridView();
            this.ColumnaNumeroCuarto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnaNombreCuarto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnaDescripcionCuarto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cuartoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpEquipo = new MetroFramework.Controls.MetroTabPage();
            this.btnBorrarEquipo = new MetroFramework.Controls.MetroButton();
            this.btnModificarEquipo = new MetroFramework.Controls.MetroButton();
            this.btnAgregarEquipo = new MetroFramework.Controls.MetroButton();
            this.btnBuscarEquipo = new MetroFramework.Controls.MetroButton();
            this.tbBuscarEquipo = new MetroFramework.Controls.MetroTextBox();
            this.dgvEquipo = new System.Windows.Forms.DataGridView();
            this.equipoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cuartoIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tpConfiguraciones = new MetroFramework.Controls.MetroTabPage();
            this.btnBorrarUsuario = new MetroFramework.Controls.MetroButton();
            this.btnAgregarUsuario = new MetroFramework.Controls.MetroButton();
            this.dgvUsuarios = new System.Windows.Forms.DataGridView();
            this.usuarioIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usuariosBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnLogin = new MetroFramework.Controls.MetroButton();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.usuariosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.empleadosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clientesTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.ClientesTableAdapter();
            this.servicioTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.ServicioTableAdapter();
            this.cuartoTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.CuartoTableAdapter();
            this.empleadosTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.EmpleadosTableAdapter();
            this.vistaCLienteTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.vistaCLienteTableAdapter();
            this.vistaEmpleadoTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.vistaEmpleadoTableAdapter();
            this.vistaCitasTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.vistaCitasTableAdapter();
            this.equipoTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.EquipoTableAdapter();
            this.lucySpaDB1 = new LucySpa.DataAccess.LucySpaDB();
            this.tratamientoTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.TratamientoTableAdapter();
            this.productosTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.ProductosTableAdapter();
            this.usuariosTableAdapter = new LucySpa.DataAccess.LucySpaDBTableAdapters.UsuariosTableAdapter();
            this.tarjetasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.citasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.citasTableAdapter = new LucySpa.DataAccess.DSTarjetasTableAdapters.CitasTableAdapter();
            this.tarjetasTableAdapter = new LucySpa.DataAccess.DSTarjetasTableAdapters.TarjetasTableAdapter();
            this.ventaTarjetasBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ventaTarjetasTableAdapter = new LucySpa.DataAccess.DSTarjetasTableAdapters.VentaTarjetasTableAdapter();
            this.vistaClientesConTarjetasTableAdapter = new LucySpa.DataAccess.DSTarjetasTableAdapters.VistaClientesConTarjetasTableAdapter();
            this.tcMenu.SuspendLayout();
            this.tpEmpleados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaEmpleadoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucySpaDB)).BeginInit();
            this.tpServicios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicioBindingSource)).BeginInit();
            this.tpTratamiento.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTratamiento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tratamientoBindingSource)).BeginInit();
            this.tpClientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaCLienteBindingSource)).BeginInit();
            this.cmsClientes.SuspendLayout();
            this.tpCitas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCitas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaCitasBindingSource)).BeginInit();
            this.tpAgenda.SuspendLayout();
            this.tpTarjetas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarjetas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaClientesConTarjetasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSTarjetas)).BeginInit();
            this.tpProductos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productosBindingSource)).BeginInit();
            this.tpCuartos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuartos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cuartoBindingSource)).BeginInit();
            this.tpEquipo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipoBindingSource)).BeginInit();
            this.tpConfiguraciones.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usuariosBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.usuariosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucySpaDB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tarjetasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.citasBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaTarjetasBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tcMenu
            // 
            this.tcMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tcMenu.Controls.Add(this.tpEmpleados);
            this.tcMenu.Controls.Add(this.tpServicios);
            this.tcMenu.Controls.Add(this.tpTratamiento);
            this.tcMenu.Controls.Add(this.tpClientes);
            this.tcMenu.Controls.Add(this.tpCitas);
            this.tcMenu.Controls.Add(this.tpAgenda);
            this.tcMenu.Controls.Add(this.tpTarjetas);
            this.tcMenu.Controls.Add(this.tpProductos);
            this.tcMenu.Controls.Add(this.tpCuartos);
            this.tcMenu.Controls.Add(this.tpEquipo);
            this.tcMenu.Controls.Add(this.tpConfiguraciones);
            this.tcMenu.CustomBackground = false;
            this.tcMenu.FontSize = MetroFramework.MetroTabControlSize.Medium;
            this.tcMenu.FontWeight = MetroFramework.MetroTabControlWeight.Light;
            this.tcMenu.Location = new System.Drawing.Point(11, 81);
            this.tcMenu.Name = "tcMenu";
            this.tcMenu.SelectedIndex = 3;
            this.tcMenu.Size = new System.Drawing.Size(1187, 480);
            this.tcMenu.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
            this.tcMenu.Style = MetroFramework.MetroColorStyle.Blue;
            this.tcMenu.StyleManager = null;
            this.tcMenu.TabIndex = 0;
            this.tcMenu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tcMenu.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tcMenu.UseStyleColors = false;
            // 
            // tpEmpleados
            // 
            this.tpEmpleados.Controls.Add(this.btnReportes);
            this.tpEmpleados.Controls.Add(this.btnBuscarEmpleado);
            this.tpEmpleados.Controls.Add(this.tbBuscarEmpleado);
            this.tpEmpleados.Controls.Add(this.btnBorrarEmpleado);
            this.tpEmpleados.Controls.Add(this.btnModificarEmpleado);
            this.tpEmpleados.Controls.Add(this.btnAgregarEmpleado);
            this.tpEmpleados.Controls.Add(this.dgvEmpleados);
            this.tpEmpleados.CustomBackground = false;
            this.tpEmpleados.HorizontalScrollbar = false;
            this.tpEmpleados.HorizontalScrollbarBarColor = true;
            this.tpEmpleados.HorizontalScrollbarHighlightOnWheel = false;
            this.tpEmpleados.HorizontalScrollbarSize = 10;
            this.tpEmpleados.Location = new System.Drawing.Point(4, 35);
            this.tpEmpleados.Name = "tpEmpleados";
            this.tpEmpleados.Size = new System.Drawing.Size(1179, 441);
            this.tpEmpleados.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpEmpleados.StyleManager = null;
            this.tpEmpleados.TabIndex = 2;
            this.tpEmpleados.Text = "Empleados";
            this.tpEmpleados.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpEmpleados.VerticalScrollbar = false;
            this.tpEmpleados.VerticalScrollbarBarColor = true;
            this.tpEmpleados.VerticalScrollbarHighlightOnWheel = false;
            this.tpEmpleados.VerticalScrollbarSize = 10;
            this.tpEmpleados.Click += new System.EventHandler(this.tpEmpleados_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnReportes.Highlight = false;
            this.btnReportes.Location = new System.Drawing.Point(653, 366);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(180, 60);
            this.btnReportes.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnReportes.StyleManager = null;
            this.btnReportes.TabIndex = 10;
            this.btnReportes.Text = "Reportes";
            this.btnReportes.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnReportes.Click += new System.EventHandler(this.btnReportes_Click);
            // 
            // btnBuscarEmpleado
            // 
            this.btnBuscarEmpleado.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarEmpleado.Highlight = false;
            this.btnBuscarEmpleado.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscarEmpleado.Name = "btnBuscarEmpleado";
            this.btnBuscarEmpleado.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarEmpleado.StyleManager = null;
            this.btnBuscarEmpleado.TabIndex = 9;
            this.btnBuscarEmpleado.Text = "Buscar..";
            this.btnBuscarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarEmpleado.Click += new System.EventHandler(this.btnBuscarEmpleado_Click);
            // 
            // tbBuscarEmpleado
            // 
            this.tbBuscarEmpleado.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarEmpleado.CustomBackground = false;
            this.tbBuscarEmpleado.CustomForeColor = false;
            this.tbBuscarEmpleado.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarEmpleado.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarEmpleado.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarEmpleado.Multiline = false;
            this.tbBuscarEmpleado.Name = "tbBuscarEmpleado";
            this.tbBuscarEmpleado.SelectedText = "";
            this.tbBuscarEmpleado.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarEmpleado.StyleManager = null;
            this.tbBuscarEmpleado.TabIndex = 8;
            this.tbBuscarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarEmpleado.UseStyleColors = false;
            this.tbBuscarEmpleado.Click += new System.EventHandler(this.tbBuscarEmpleado_Click);
            this.tbBuscarEmpleado.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbBuscarEmpleado_KeyUp);
            // 
            // btnBorrarEmpleado
            // 
            this.btnBorrarEmpleado.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarEmpleado.Highlight = false;
            this.btnBorrarEmpleado.Location = new System.Drawing.Point(452, 366);
            this.btnBorrarEmpleado.Name = "btnBorrarEmpleado";
            this.btnBorrarEmpleado.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarEmpleado.StyleManager = null;
            this.btnBorrarEmpleado.TabIndex = 7;
            this.btnBorrarEmpleado.Text = "Borrar";
            this.btnBorrarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarEmpleado.Click += new System.EventHandler(this.metroButton1_Click_1);
            // 
            // btnModificarEmpleado
            // 
            this.btnModificarEmpleado.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarEmpleado.Highlight = false;
            this.btnModificarEmpleado.Location = new System.Drawing.Point(237, 366);
            this.btnModificarEmpleado.Name = "btnModificarEmpleado";
            this.btnModificarEmpleado.Size = new System.Drawing.Size(180, 60);
            this.btnModificarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarEmpleado.StyleManager = null;
            this.btnModificarEmpleado.TabIndex = 6;
            this.btnModificarEmpleado.Text = "Modificar";
            this.btnModificarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarEmpleado.Click += new System.EventHandler(this.btModificarEmpleado_Click_2);
            // 
            // btnAgregarEmpleado
            // 
            this.btnAgregarEmpleado.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarEmpleado.Highlight = false;
            this.btnAgregarEmpleado.Location = new System.Drawing.Point(21, 366);
            this.btnAgregarEmpleado.Name = "btnAgregarEmpleado";
            this.btnAgregarEmpleado.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarEmpleado.StyleManager = null;
            this.btnAgregarEmpleado.TabIndex = 3;
            this.btnAgregarEmpleado.Text = "Agregar";
            this.btnAgregarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarEmpleado.Click += new System.EventHandler(this.btnAgregarEmpleado_Click);
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.AllowUserToAddRows = false;
            this.dgvEmpleados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEmpleados.AutoGenerateColumns = false;
            this.dgvEmpleados.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEmpleados.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.empleadoIDDataGridViewTextBoxColumn,
            this.apellidoDataGridViewTextBoxColumn1,
            this.nombreDataGridViewTextBoxColumn2,
            this.cumpleañosDataGridViewTextBoxColumn1,
            this.direccionDataGridViewTextBoxColumn1,
            this.telefonoDataGridViewTextBoxColumn1,
            this.emailDataGridViewTextBoxColumn1,
            this.fotografiaEmppleado});
            this.dgvEmpleados.DataSource = this.vistaEmpleadoBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEmpleados.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEmpleados.Location = new System.Drawing.Point(0, 60);
            this.dgvEmpleados.MultiSelect = false;
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.ReadOnly = true;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvEmpleados.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvEmpleados.RowTemplate.Height = 60;
            this.dgvEmpleados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmpleados.Size = new System.Drawing.Size(1144, 282);
            this.dgvEmpleados.TabIndex = 2;
            this.dgvEmpleados.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEmpleados_CellContentClick);
            // 
            // empleadoIDDataGridViewTextBoxColumn
            // 
            this.empleadoIDDataGridViewTextBoxColumn.DataPropertyName = "EmpleadoID";
            this.empleadoIDDataGridViewTextBoxColumn.HeaderText = "Empleado ID";
            this.empleadoIDDataGridViewTextBoxColumn.Name = "empleadoIDDataGridViewTextBoxColumn";
            this.empleadoIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.empleadoIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // apellidoDataGridViewTextBoxColumn1
            // 
            this.apellidoDataGridViewTextBoxColumn1.DataPropertyName = "Apellido";
            this.apellidoDataGridViewTextBoxColumn1.HeaderText = "Apellido";
            this.apellidoDataGridViewTextBoxColumn1.Name = "apellidoDataGridViewTextBoxColumn1";
            this.apellidoDataGridViewTextBoxColumn1.ReadOnly = true;
            this.apellidoDataGridViewTextBoxColumn1.Width = 150;
            // 
            // nombreDataGridViewTextBoxColumn2
            // 
            this.nombreDataGridViewTextBoxColumn2.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn2.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn2.Name = "nombreDataGridViewTextBoxColumn2";
            this.nombreDataGridViewTextBoxColumn2.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn2.Width = 150;
            // 
            // cumpleañosDataGridViewTextBoxColumn1
            // 
            this.cumpleañosDataGridViewTextBoxColumn1.DataPropertyName = "Cumpleaños";
            this.cumpleañosDataGridViewTextBoxColumn1.HeaderText = "Cumpleaños";
            this.cumpleañosDataGridViewTextBoxColumn1.Name = "cumpleañosDataGridViewTextBoxColumn1";
            this.cumpleañosDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // direccionDataGridViewTextBoxColumn1
            // 
            this.direccionDataGridViewTextBoxColumn1.DataPropertyName = "Direccion";
            this.direccionDataGridViewTextBoxColumn1.HeaderText = "Direccion";
            this.direccionDataGridViewTextBoxColumn1.Name = "direccionDataGridViewTextBoxColumn1";
            this.direccionDataGridViewTextBoxColumn1.ReadOnly = true;
            this.direccionDataGridViewTextBoxColumn1.Width = 300;
            // 
            // telefonoDataGridViewTextBoxColumn1
            // 
            this.telefonoDataGridViewTextBoxColumn1.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn1.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn1.Name = "telefonoDataGridViewTextBoxColumn1";
            this.telefonoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn1
            // 
            this.emailDataGridViewTextBoxColumn1.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn1.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn1.Name = "emailDataGridViewTextBoxColumn1";
            this.emailDataGridViewTextBoxColumn1.ReadOnly = true;
            this.emailDataGridViewTextBoxColumn1.Width = 250;
            // 
            // fotografiaEmppleado
            // 
            this.fotografiaEmppleado.DataPropertyName = "fotografiaEmppleado";
            this.fotografiaEmppleado.HeaderText = "Fotografia";
            this.fotografiaEmppleado.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.fotografiaEmppleado.Name = "fotografiaEmppleado";
            this.fotografiaEmppleado.ReadOnly = true;
            // 
            // vistaEmpleadoBindingSource
            // 
            this.vistaEmpleadoBindingSource.DataMember = "vistaEmpleado";
            this.vistaEmpleadoBindingSource.DataSource = this.lucySpaDB;
            // 
            // lucySpaDB
            // 
            this.lucySpaDB.DataSetName = "LucySpaDB";
            this.lucySpaDB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tpServicios
            // 
            this.tpServicios.Controls.Add(this.btnBuscarServicio);
            this.tpServicios.Controls.Add(this.btnBorrarServicio);
            this.tpServicios.Controls.Add(this.btnModificarServicio);
            this.tpServicios.Controls.Add(this.tbBuscarServicio);
            this.tpServicios.Controls.Add(this.btnGuardarEmpleado);
            this.tpServicios.Controls.Add(this.dgvServicios);
            this.tpServicios.CustomBackground = false;
            this.tpServicios.HorizontalScrollbar = false;
            this.tpServicios.HorizontalScrollbarBarColor = true;
            this.tpServicios.HorizontalScrollbarHighlightOnWheel = false;
            this.tpServicios.HorizontalScrollbarSize = 10;
            this.tpServicios.Location = new System.Drawing.Point(4, 35);
            this.tpServicios.Name = "tpServicios";
            this.tpServicios.Size = new System.Drawing.Size(1179, 441);
            this.tpServicios.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpServicios.StyleManager = null;
            this.tpServicios.TabIndex = 3;
            this.tpServicios.Text = "Servicios";
            this.tpServicios.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpServicios.VerticalScrollbar = false;
            this.tpServicios.VerticalScrollbarBarColor = true;
            this.tpServicios.VerticalScrollbarHighlightOnWheel = false;
            this.tpServicios.VerticalScrollbarSize = 10;
            this.tpServicios.Click += new System.EventHandler(this.tpServicios_Click);
            // 
            // btnBuscarServicio
            // 
            this.btnBuscarServicio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarServicio.Highlight = false;
            this.btnBuscarServicio.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscarServicio.Name = "btnBuscarServicio";
            this.btnBuscarServicio.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarServicio.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarServicio.StyleManager = null;
            this.btnBuscarServicio.TabIndex = 10;
            this.btnBuscarServicio.Text = "Buscar..";
            this.btnBuscarServicio.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarServicio.Click += new System.EventHandler(this.btnBuscarServicio_Click);
            // 
            // btnBorrarServicio
            // 
            this.btnBorrarServicio.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarServicio.Highlight = false;
            this.btnBorrarServicio.Location = new System.Drawing.Point(597, 366);
            this.btnBorrarServicio.Name = "btnBorrarServicio";
            this.btnBorrarServicio.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarServicio.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarServicio.StyleManager = null;
            this.btnBorrarServicio.TabIndex = 9;
            this.btnBorrarServicio.Text = "Borrar";
            this.btnBorrarServicio.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarServicio.Click += new System.EventHandler(this.btnBorrarServicio_Click);
            // 
            // btnModificarServicio
            // 
            this.btnModificarServicio.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarServicio.Highlight = false;
            this.btnModificarServicio.Location = new System.Drawing.Point(382, 366);
            this.btnModificarServicio.Name = "btnModificarServicio";
            this.btnModificarServicio.Size = new System.Drawing.Size(180, 60);
            this.btnModificarServicio.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarServicio.StyleManager = null;
            this.btnModificarServicio.TabIndex = 8;
            this.btnModificarServicio.Text = "Modificar";
            this.btnModificarServicio.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarServicio.Click += new System.EventHandler(this.btnModificarServicio_Click);
            // 
            // tbBuscarServicio
            // 
            this.tbBuscarServicio.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarServicio.CustomBackground = false;
            this.tbBuscarServicio.CustomForeColor = false;
            this.tbBuscarServicio.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarServicio.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarServicio.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarServicio.Multiline = false;
            this.tbBuscarServicio.Name = "tbBuscarServicio";
            this.tbBuscarServicio.SelectedText = "";
            this.tbBuscarServicio.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarServicio.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarServicio.StyleManager = null;
            this.tbBuscarServicio.TabIndex = 4;
            this.tbBuscarServicio.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarServicio.UseStyleColors = false;
            this.tbBuscarServicio.TextChanged += new System.EventHandler(this.tbBuscarServicio_TextChanged);
            this.tbBuscarServicio.Click += new System.EventHandler(this.tbBuscarServicio_Click);
            // 
            // btnGuardarEmpleado
            // 
            this.btnGuardarEmpleado.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnGuardarEmpleado.Highlight = false;
            this.btnGuardarEmpleado.Location = new System.Drawing.Point(166, 366);
            this.btnGuardarEmpleado.Name = "btnGuardarEmpleado";
            this.btnGuardarEmpleado.Size = new System.Drawing.Size(180, 60);
            this.btnGuardarEmpleado.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnGuardarEmpleado.StyleManager = null;
            this.btnGuardarEmpleado.TabIndex = 3;
            this.btnGuardarEmpleado.Text = "Agregar";
            this.btnGuardarEmpleado.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnGuardarEmpleado.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // dgvServicios
            // 
            this.dgvServicios.AllowUserToAddRows = false;
            this.dgvServicios.AllowUserToDeleteRows = false;
            this.dgvServicios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvServicios.AutoGenerateColumns = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvServicios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvServicios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServicios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.servicioIDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn1,
            this.costoDataGridViewTextBoxColumn,
            this.descripcionDataGridViewTextBoxColumn});
            this.dgvServicios.DataSource = this.servicioBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvServicios.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvServicios.Location = new System.Drawing.Point(0, 65);
            this.dgvServicios.MultiSelect = false;
            this.dgvServicios.Name = "dgvServicios";
            this.dgvServicios.ReadOnly = true;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvServicios.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvServicios.RowTemplate.Height = 60;
            this.dgvServicios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvServicios.Size = new System.Drawing.Size(1144, 282);
            this.dgvServicios.TabIndex = 2;
            this.dgvServicios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick_1);
            this.dgvServicios.Click += new System.EventHandler(this.dgvServicios_Click);
            // 
            // servicioIDDataGridViewTextBoxColumn
            // 
            this.servicioIDDataGridViewTextBoxColumn.DataPropertyName = "ServicioID";
            this.servicioIDDataGridViewTextBoxColumn.HeaderText = "Numero de Servicio";
            this.servicioIDDataGridViewTextBoxColumn.Name = "servicioIDDataGridViewTextBoxColumn";
            this.servicioIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn1
            // 
            this.nombreDataGridViewTextBoxColumn1.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn1.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn1.Name = "nombreDataGridViewTextBoxColumn1";
            this.nombreDataGridViewTextBoxColumn1.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn1.Width = 200;
            // 
            // costoDataGridViewTextBoxColumn
            // 
            this.costoDataGridViewTextBoxColumn.DataPropertyName = "Costo";
            dataGridViewCellStyle5.Format = "C2";
            dataGridViewCellStyle5.NullValue = null;
            this.costoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.costoDataGridViewTextBoxColumn.HeaderText = "Costo";
            this.costoDataGridViewTextBoxColumn.Name = "costoDataGridViewTextBoxColumn";
            this.costoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descripcionDataGridViewTextBoxColumn
            // 
            this.descripcionDataGridViewTextBoxColumn.DataPropertyName = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn.HeaderText = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn.Name = "descripcionDataGridViewTextBoxColumn";
            this.descripcionDataGridViewTextBoxColumn.ReadOnly = true;
            this.descripcionDataGridViewTextBoxColumn.Width = 500;
            // 
            // servicioBindingSource
            // 
            this.servicioBindingSource.DataMember = "Servicio";
            this.servicioBindingSource.DataSource = this.lucySpaDB;
            // 
            // tpTratamiento
            // 
            this.tpTratamiento.Controls.Add(this.btnmodificarTratamiento);
            this.tpTratamiento.Controls.Add(this.btnBorrar);
            this.tpTratamiento.Controls.Add(this.btnDetalles);
            this.tpTratamiento.Controls.Add(this.btnVender);
            this.tpTratamiento.Controls.Add(this.btnAgregarTratamiento);
            this.tpTratamiento.Controls.Add(this.btnBuscarTratamiento);
            this.tpTratamiento.Controls.Add(this.tbBsucarTratamiento);
            this.tpTratamiento.Controls.Add(this.dgvTratamiento);
            this.tpTratamiento.CustomBackground = false;
            this.tpTratamiento.HorizontalScrollbar = false;
            this.tpTratamiento.HorizontalScrollbarBarColor = true;
            this.tpTratamiento.HorizontalScrollbarHighlightOnWheel = false;
            this.tpTratamiento.HorizontalScrollbarSize = 10;
            this.tpTratamiento.Location = new System.Drawing.Point(4, 35);
            this.tpTratamiento.Name = "tpTratamiento";
            this.tpTratamiento.Size = new System.Drawing.Size(1179, 441);
            this.tpTratamiento.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpTratamiento.StyleManager = null;
            this.tpTratamiento.TabIndex = 4;
            this.tpTratamiento.Text = "Tratamientos";
            this.tpTratamiento.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpTratamiento.VerticalScrollbar = false;
            this.tpTratamiento.VerticalScrollbarBarColor = true;
            this.tpTratamiento.VerticalScrollbarHighlightOnWheel = false;
            this.tpTratamiento.VerticalScrollbarSize = 10;
            this.tpTratamiento.Click += new System.EventHandler(this.tpTratamiento_Click);
            // 
            // btnmodificarTratamiento
            // 
            this.btnmodificarTratamiento.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnmodificarTratamiento.Highlight = false;
            this.btnmodificarTratamiento.Location = new System.Drawing.Point(209, 325);
            this.btnmodificarTratamiento.Name = "btnmodificarTratamiento";
            this.btnmodificarTratamiento.Size = new System.Drawing.Size(180, 60);
            this.btnmodificarTratamiento.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnmodificarTratamiento.StyleManager = null;
            this.btnmodificarTratamiento.TabIndex = 39;
            this.btnmodificarTratamiento.Text = "Modificar";
            this.btnmodificarTratamiento.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnmodificarTratamiento.Click += new System.EventHandler(this.btnmodificarTratamiento_Click);
            // 
            // btnBorrar
            // 
            this.btnBorrar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrar.Highlight = false;
            this.btnBorrar.Location = new System.Drawing.Point(408, 325);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(180, 60);
            this.btnBorrar.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrar.StyleManager = null;
            this.btnBorrar.TabIndex = 38;
            this.btnBorrar.Text = "Borrar";
            this.btnBorrar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrar.Click += new System.EventHandler(this.btnBorrar_Click);
            // 
            // btnDetalles
            // 
            this.btnDetalles.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnDetalles.Highlight = false;
            this.btnDetalles.Location = new System.Drawing.Point(5, 325);
            this.btnDetalles.Name = "btnDetalles";
            this.btnDetalles.Size = new System.Drawing.Size(180, 60);
            this.btnDetalles.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnDetalles.StyleManager = null;
            this.btnDetalles.TabIndex = 37;
            this.btnDetalles.Text = "Detalles del Tratamiento";
            this.btnDetalles.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnDetalles.Click += new System.EventHandler(this.btnDetalles_Click);
            // 
            // btnVender
            // 
            this.btnVender.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnVender.Highlight = false;
            this.btnVender.Location = new System.Drawing.Point(811, 325);
            this.btnVender.Name = "btnVender";
            this.btnVender.Size = new System.Drawing.Size(180, 60);
            this.btnVender.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnVender.StyleManager = null;
            this.btnVender.TabIndex = 13;
            this.btnVender.Text = "Vender Tratamiento";
            this.btnVender.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnVender.Click += new System.EventHandler(this.btnVender_Click);
            // 
            // btnAgregarTratamiento
            // 
            this.btnAgregarTratamiento.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarTratamiento.Highlight = false;
            this.btnAgregarTratamiento.Location = new System.Drawing.Point(607, 325);
            this.btnAgregarTratamiento.Name = "btnAgregarTratamiento";
            this.btnAgregarTratamiento.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarTratamiento.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarTratamiento.StyleManager = null;
            this.btnAgregarTratamiento.TabIndex = 11;
            this.btnAgregarTratamiento.Text = "Nuevo Tratamiento";
            this.btnAgregarTratamiento.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarTratamiento.Click += new System.EventHandler(this.btnAgregarTratamiento_Click);
            // 
            // btnBuscarTratamiento
            // 
            this.btnBuscarTratamiento.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarTratamiento.Highlight = false;
            this.btnBuscarTratamiento.Location = new System.Drawing.Point(1005, 14);
            this.btnBuscarTratamiento.Name = "btnBuscarTratamiento";
            this.btnBuscarTratamiento.Size = new System.Drawing.Size(139, 40);
            this.btnBuscarTratamiento.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarTratamiento.StyleManager = null;
            this.btnBuscarTratamiento.TabIndex = 19;
            this.btnBuscarTratamiento.Text = "Buscar..";
            this.btnBuscarTratamiento.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarTratamiento.Click += new System.EventHandler(this.btnBuscarTratamiento_Click);
            // 
            // tbBsucarTratamiento
            // 
            this.tbBsucarTratamiento.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBsucarTratamiento.CustomBackground = false;
            this.tbBsucarTratamiento.CustomForeColor = false;
            this.tbBsucarTratamiento.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBsucarTratamiento.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBsucarTratamiento.Location = new System.Drawing.Point(3, 14);
            this.tbBsucarTratamiento.Multiline = false;
            this.tbBsucarTratamiento.Name = "tbBsucarTratamiento";
            this.tbBsucarTratamiento.SelectedText = "";
            this.tbBsucarTratamiento.Size = new System.Drawing.Size(996, 40);
            this.tbBsucarTratamiento.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBsucarTratamiento.StyleManager = null;
            this.tbBsucarTratamiento.TabIndex = 18;
            this.tbBsucarTratamiento.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBsucarTratamiento.UseStyleColors = false;
            // 
            // dgvTratamiento
            // 
            this.dgvTratamiento.AllowUserToAddRows = false;
            this.dgvTratamiento.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTratamiento.AutoGenerateColumns = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTratamiento.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvTratamiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTratamiento.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tratamientoIDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn5,
            this.descripcionDataGridViewTextBoxColumn3,
            this.precioCatalogo});
            this.dgvTratamiento.DataSource = this.tratamientoBindingSource;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTratamiento.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvTratamiento.Location = new System.Drawing.Point(0, 60);
            this.dgvTratamiento.MultiSelect = false;
            this.dgvTratamiento.Name = "dgvTratamiento";
            this.dgvTratamiento.ReadOnly = true;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTratamiento.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTratamiento.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvTratamiento.RowTemplate.Height = 60;
            this.dgvTratamiento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTratamiento.Size = new System.Drawing.Size(1144, 259);
            this.dgvTratamiento.TabIndex = 10;
            // 
            // tratamientoIDDataGridViewTextBoxColumn
            // 
            this.tratamientoIDDataGridViewTextBoxColumn.DataPropertyName = "TratamientoID";
            this.tratamientoIDDataGridViewTextBoxColumn.HeaderText = "TratamientoID";
            this.tratamientoIDDataGridViewTextBoxColumn.Name = "tratamientoIDDataGridViewTextBoxColumn";
            this.tratamientoIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.tratamientoIDDataGridViewTextBoxColumn.Width = 200;
            // 
            // nombreDataGridViewTextBoxColumn5
            // 
            this.nombreDataGridViewTextBoxColumn5.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn5.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn5.Name = "nombreDataGridViewTextBoxColumn5";
            this.nombreDataGridViewTextBoxColumn5.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn5.Width = 200;
            // 
            // descripcionDataGridViewTextBoxColumn3
            // 
            this.descripcionDataGridViewTextBoxColumn3.DataPropertyName = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn3.HeaderText = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn3.Name = "descripcionDataGridViewTextBoxColumn3";
            this.descripcionDataGridViewTextBoxColumn3.ReadOnly = true;
            this.descripcionDataGridViewTextBoxColumn3.Width = 200;
            // 
            // precioCatalogo
            // 
            this.precioCatalogo.DataPropertyName = "precioCatalogo";
            this.precioCatalogo.HeaderText = "precioCatalogo";
            this.precioCatalogo.Name = "precioCatalogo";
            this.precioCatalogo.ReadOnly = true;
            // 
            // tratamientoBindingSource
            // 
            this.tratamientoBindingSource.DataMember = "Tratamiento";
            this.tratamientoBindingSource.DataSource = this.lucySpaDB;
            // 
            // tpClientes
            // 
            this.tpClientes.Controls.Add(this.btnVenderProducto);
            this.tpClientes.Controls.Add(this.btnAsignarTarjeta);
            this.tpClientes.Controls.Add(this.btnAgendarCita);
            this.tpClientes.Controls.Add(this.btnBuscar);
            this.tpClientes.Controls.Add(this.tbBuscarCliente);
            this.tpClientes.Controls.Add(this.btnBorrarCliente);
            this.tpClientes.Controls.Add(this.btnModificarCliente);
            this.tpClientes.Controls.Add(this.btnAgregarCliente);
            this.tpClientes.Controls.Add(this.dgvClientes);
            this.tpClientes.CustomBackground = false;
            this.tpClientes.HorizontalScrollbar = false;
            this.tpClientes.HorizontalScrollbarBarColor = true;
            this.tpClientes.HorizontalScrollbarHighlightOnWheel = false;
            this.tpClientes.HorizontalScrollbarSize = 10;
            this.tpClientes.Location = new System.Drawing.Point(4, 35);
            this.tpClientes.Name = "tpClientes";
            this.tpClientes.Size = new System.Drawing.Size(1179, 441);
            this.tpClientes.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpClientes.StyleManager = null;
            this.tpClientes.TabIndex = 0;
            this.tpClientes.Text = "Clientes";
            this.tpClientes.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpClientes.VerticalScrollbar = false;
            this.tpClientes.VerticalScrollbarBarColor = true;
            this.tpClientes.VerticalScrollbarHighlightOnWheel = false;
            this.tpClientes.VerticalScrollbarSize = 10;
            this.tpClientes.Click += new System.EventHandler(this.tpClientes_Click);
            // 
            // btnVenderProducto
            // 
            this.btnVenderProducto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnVenderProducto.Highlight = false;
            this.btnVenderProducto.Location = new System.Drawing.Point(988, 359);
            this.btnVenderProducto.Name = "btnVenderProducto";
            this.btnVenderProducto.Size = new System.Drawing.Size(180, 60);
            this.btnVenderProducto.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnVenderProducto.StyleManager = null;
            this.btnVenderProducto.TabIndex = 10;
            this.btnVenderProducto.Text = "Vender Producto";
            this.btnVenderProducto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnVenderProducto.Click += new System.EventHandler(this.btnVenderProducto_Click);
            // 
            // btnAsignarTarjeta
            // 
            this.btnAsignarTarjeta.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAsignarTarjeta.Highlight = false;
            this.btnAsignarTarjeta.Location = new System.Drawing.Point(802, 359);
            this.btnAsignarTarjeta.Name = "btnAsignarTarjeta";
            this.btnAsignarTarjeta.Size = new System.Drawing.Size(180, 60);
            this.btnAsignarTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAsignarTarjeta.StyleManager = null;
            this.btnAsignarTarjeta.TabIndex = 9;
            this.btnAsignarTarjeta.Text = "Asignar Tarjeta";
            this.btnAsignarTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAsignarTarjeta.Click += new System.EventHandler(this.btnAsignarTarjeta_Click);
            // 
            // btnAgendarCita
            // 
            this.btnAgendarCita.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgendarCita.Highlight = false;
            this.btnAgendarCita.Location = new System.Drawing.Point(616, 359);
            this.btnAgendarCita.Name = "btnAgendarCita";
            this.btnAgendarCita.Size = new System.Drawing.Size(180, 60);
            this.btnAgendarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgendarCita.StyleManager = null;
            this.btnAgendarCita.TabIndex = 8;
            this.btnAgendarCita.Text = "Agendar Cita";
            this.btnAgendarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgendarCita.Click += new System.EventHandler(this.btnAgendarCita_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscar.Highlight = false;
            this.btnBuscar.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(140, 40);
            this.btnBuscar.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscar.StyleManager = null;
            this.btnBuscar.TabIndex = 7;
            this.btnBuscar.Text = "Buscar..";
            this.btnBuscar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscarCliente_Click);
            // 
            // tbBuscarCliente
            // 
            this.tbBuscarCliente.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarCliente.CustomBackground = false;
            this.tbBuscarCliente.CustomForeColor = false;
            this.tbBuscarCliente.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarCliente.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarCliente.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarCliente.Multiline = false;
            this.tbBuscarCliente.Name = "tbBuscarCliente";
            this.tbBuscarCliente.SelectedText = "";
            this.tbBuscarCliente.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarCliente.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarCliente.StyleManager = null;
            this.tbBuscarCliente.TabIndex = 6;
            this.tbBuscarCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarCliente.UseStyleColors = false;
            this.tbBuscarCliente.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbBuscarCliente_KeyUp);
            // 
            // btnBorrarCliente
            // 
            this.btnBorrarCliente.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarCliente.Highlight = false;
            this.btnBorrarCliente.Location = new System.Drawing.Point(430, 359);
            this.btnBorrarCliente.Name = "btnBorrarCliente";
            this.btnBorrarCliente.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarCliente.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarCliente.StyleManager = null;
            this.btnBorrarCliente.TabIndex = 5;
            this.btnBorrarCliente.Text = "Borrar";
            this.btnBorrarCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarCliente.Click += new System.EventHandler(this.btnBorrarCliente_Click);
            // 
            // btnModificarCliente
            // 
            this.btnModificarCliente.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarCliente.Highlight = false;
            this.btnModificarCliente.Location = new System.Drawing.Point(244, 359);
            this.btnModificarCliente.Name = "btnModificarCliente";
            this.btnModificarCliente.Size = new System.Drawing.Size(180, 60);
            this.btnModificarCliente.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarCliente.StyleManager = null;
            this.btnModificarCliente.TabIndex = 4;
            this.btnModificarCliente.Text = "Modificar";
            this.btnModificarCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarCliente.Click += new System.EventHandler(this.btnModificarCliente_Click);
            // 
            // btnAgregarCliente
            // 
            this.btnAgregarCliente.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarCliente.Highlight = false;
            this.btnAgregarCliente.Location = new System.Drawing.Point(58, 359);
            this.btnAgregarCliente.Name = "btnAgregarCliente";
            this.btnAgregarCliente.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarCliente.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarCliente.StyleManager = null;
            this.btnAgregarCliente.TabIndex = 3;
            this.btnAgregarCliente.Text = "Agregar";
            this.btnAgregarCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarCliente.Click += new System.EventHandler(this.btnAgregarCliente_Click);
            // 
            // dgvClientes
            // 
            this.dgvClientes.AllowUserToAddRows = false;
            this.dgvClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvClientes.AutoGenerateColumns = false;
            this.dgvClientes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Honeydew;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvClientes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clienteIDDataGridViewTextBoxColumn,
            this.nombreCompleto,
            this.cumpleañosDataGridViewTextBoxColumn,
            this.direccionDataGridViewTextBoxColumn,
            this.telefonoDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.fotografiaCliente});
            this.dgvClientes.DataSource = this.vistaCLienteBindingSource;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvClientes.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgvClientes.Location = new System.Drawing.Point(0, 65);
            this.dgvClientes.MultiSelect = false;
            this.dgvClientes.Name = "dgvClientes";
            this.dgvClientes.ReadOnly = true;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvClientes.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvClientes.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvClientes.RowTemplate.ContextMenuStrip = this.cmsClientes;
            this.dgvClientes.RowTemplate.Height = 60;
            this.dgvClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvClientes.Size = new System.Drawing.Size(1144, 288);
            this.dgvClientes.TabIndex = 2;
            // 
            // clienteIDDataGridViewTextBoxColumn
            // 
            this.clienteIDDataGridViewTextBoxColumn.DataPropertyName = "ClienteID";
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clienteIDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.clienteIDDataGridViewTextBoxColumn.HeaderText = "Numero de Socio";
            this.clienteIDDataGridViewTextBoxColumn.Name = "clienteIDDataGridViewTextBoxColumn";
            this.clienteIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreCompleto
            // 
            this.nombreCompleto.DataPropertyName = "nombreCompleto";
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreCompleto.DefaultCellStyle = dataGridViewCellStyle14;
            this.nombreCompleto.HeaderText = "Nombre";
            this.nombreCompleto.Name = "nombreCompleto";
            this.nombreCompleto.ReadOnly = true;
            this.nombreCompleto.Width = 350;
            // 
            // cumpleañosDataGridViewTextBoxColumn
            // 
            this.cumpleañosDataGridViewTextBoxColumn.DataPropertyName = "Cumpleaños";
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cumpleañosDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle15;
            this.cumpleañosDataGridViewTextBoxColumn.HeaderText = "Cumpleaños";
            this.cumpleañosDataGridViewTextBoxColumn.Name = "cumpleañosDataGridViewTextBoxColumn";
            this.cumpleañosDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // direccionDataGridViewTextBoxColumn
            // 
            this.direccionDataGridViewTextBoxColumn.DataPropertyName = "Direccion";
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.direccionDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle16;
            this.direccionDataGridViewTextBoxColumn.HeaderText = "Direccion";
            this.direccionDataGridViewTextBoxColumn.Name = "direccionDataGridViewTextBoxColumn";
            this.direccionDataGridViewTextBoxColumn.ReadOnly = true;
            this.direccionDataGridViewTextBoxColumn.Width = 300;
            // 
            // telefonoDataGridViewTextBoxColumn
            // 
            this.telefonoDataGridViewTextBoxColumn.DataPropertyName = "Telefono";
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.telefonoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle17;
            this.telefonoDataGridViewTextBoxColumn.HeaderText = "Telefono";
            this.telefonoDataGridViewTextBoxColumn.Name = "telefonoDataGridViewTextBoxColumn";
            this.telefonoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle18;
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.ReadOnly = true;
            this.emailDataGridViewTextBoxColumn.Width = 250;
            // 
            // fotografiaCliente
            // 
            this.fotografiaCliente.DataPropertyName = "fotografiaCliente";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.NullValue = null;
            this.fotografiaCliente.DefaultCellStyle = dataGridViewCellStyle19;
            this.fotografiaCliente.HeaderText = "Fotografia";
            this.fotografiaCliente.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.fotografiaCliente.Name = "fotografiaCliente";
            this.fotografiaCliente.ReadOnly = true;
            // 
            // vistaCLienteBindingSource
            // 
            this.vistaCLienteBindingSource.DataMember = "vistaCLiente";
            this.vistaCLienteBindingSource.DataSource = this.lucySpaDB;
            // 
            // cmsClientes
            // 
            this.cmsClientes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tratamientosVendidosToolStripMenuItem});
            this.cmsClientes.Name = "cmsClientes";
            this.cmsClientes.Size = new System.Drawing.Size(197, 26);
            // 
            // tratamientosVendidosToolStripMenuItem
            // 
            this.tratamientosVendidosToolStripMenuItem.Name = "tratamientosVendidosToolStripMenuItem";
            this.tratamientosVendidosToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.tratamientosVendidosToolStripMenuItem.Text = "Tratamientos Vendidos";
            this.tratamientosVendidosToolStripMenuItem.Click += new System.EventHandler(this.tratamientosVendidosToolStripMenuItem_Click);
            // 
            // tpCitas
            // 
            this.tpCitas.Controls.Add(this.btnCancelarCita);
            this.tpCitas.Controls.Add(this.btnPagar);
            this.tpCitas.Controls.Add(this.btnAdministrar);
            this.tpCitas.Controls.Add(this.mbtnBuscarCita);
            this.tpCitas.Controls.Add(this.btnBorrarCita);
            this.tpCitas.Controls.Add(this.btnModificarCita);
            this.tpCitas.Controls.Add(this.tbBuscarCita);
            this.tpCitas.Controls.Add(this.dgvCitas);
            this.tpCitas.CustomBackground = false;
            this.tpCitas.HorizontalScrollbar = false;
            this.tpCitas.HorizontalScrollbarBarColor = true;
            this.tpCitas.HorizontalScrollbarHighlightOnWheel = false;
            this.tpCitas.HorizontalScrollbarSize = 10;
            this.tpCitas.Location = new System.Drawing.Point(4, 35);
            this.tpCitas.Name = "tpCitas";
            this.tpCitas.Size = new System.Drawing.Size(1179, 441);
            this.tpCitas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpCitas.StyleManager = null;
            this.tpCitas.TabIndex = 1;
            this.tpCitas.Text = "Citas";
            this.tpCitas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpCitas.VerticalScrollbar = false;
            this.tpCitas.VerticalScrollbarBarColor = true;
            this.tpCitas.VerticalScrollbarHighlightOnWheel = false;
            this.tpCitas.VerticalScrollbarSize = 10;
            this.tpCitas.Click += new System.EventHandler(this.tpCitas_Click);
            // 
            // btnCancelarCita
            // 
            this.btnCancelarCita.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnCancelarCita.Highlight = false;
            this.btnCancelarCita.Location = new System.Drawing.Point(882, 378);
            this.btnCancelarCita.Name = "btnCancelarCita";
            this.btnCancelarCita.Size = new System.Drawing.Size(180, 53);
            this.btnCancelarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnCancelarCita.StyleManager = null;
            this.btnCancelarCita.TabIndex = 11;
            this.btnCancelarCita.Text = "Cancelar Cita";
            this.btnCancelarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnCancelarCita.Click += new System.EventHandler(this.btnCancelarCita_Click);
            // 
            // btnPagar
            // 
            this.btnPagar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnPagar.Highlight = false;
            this.btnPagar.Location = new System.Drawing.Point(60, 381);
            this.btnPagar.Name = "btnPagar";
            this.btnPagar.Size = new System.Drawing.Size(180, 53);
            this.btnPagar.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnPagar.StyleManager = null;
            this.btnPagar.TabIndex = 10;
            this.btnPagar.Text = "Pagar";
            this.btnPagar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnPagar.Click += new System.EventHandler(this.btnPagar_Click);
            // 
            // btnAdministrar
            // 
            this.btnAdministrar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAdministrar.Highlight = false;
            this.btnAdministrar.Location = new System.Drawing.Point(687, 378);
            this.btnAdministrar.Name = "btnAdministrar";
            this.btnAdministrar.Size = new System.Drawing.Size(180, 53);
            this.btnAdministrar.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAdministrar.StyleManager = null;
            this.btnAdministrar.TabIndex = 9;
            this.btnAdministrar.Text = "Pendientes";
            this.btnAdministrar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAdministrar.Click += new System.EventHandler(this.btnAdministrar_Click);
            // 
            // mbtnBuscarCita
            // 
            this.mbtnBuscarCita.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mbtnBuscarCita.Highlight = false;
            this.mbtnBuscarCita.Location = new System.Drawing.Point(1004, 14);
            this.mbtnBuscarCita.Name = "mbtnBuscarCita";
            this.mbtnBuscarCita.Size = new System.Drawing.Size(140, 40);
            this.mbtnBuscarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.mbtnBuscarCita.StyleManager = null;
            this.mbtnBuscarCita.TabIndex = 8;
            this.mbtnBuscarCita.Text = "Buscar..";
            this.mbtnBuscarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.mbtnBuscarCita.Click += new System.EventHandler(this.btnBuscarCita_Click);
            // 
            // btnBorrarCita
            // 
            this.btnBorrarCita.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarCita.Highlight = false;
            this.btnBorrarCita.Location = new System.Drawing.Point(486, 374);
            this.btnBorrarCita.Name = "btnBorrarCita";
            this.btnBorrarCita.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarCita.StyleManager = null;
            this.btnBorrarCita.TabIndex = 7;
            this.btnBorrarCita.Text = "Borrar";
            this.btnBorrarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarCita.Click += new System.EventHandler(this.btnBorrarCita_Click);
            // 
            // btnModificarCita
            // 
            this.btnModificarCita.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarCita.Highlight = false;
            this.btnModificarCita.Location = new System.Drawing.Point(263, 378);
            this.btnModificarCita.Name = "btnModificarCita";
            this.btnModificarCita.Size = new System.Drawing.Size(180, 53);
            this.btnModificarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarCita.StyleManager = null;
            this.btnModificarCita.TabIndex = 6;
            this.btnModificarCita.Text = "Modificar";
            this.btnModificarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarCita.Click += new System.EventHandler(this.btnModificarCita_Click);
            // 
            // tbBuscarCita
            // 
            this.tbBuscarCita.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarCita.CustomBackground = false;
            this.tbBuscarCita.CustomForeColor = false;
            this.tbBuscarCita.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarCita.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarCita.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarCita.Multiline = false;
            this.tbBuscarCita.Name = "tbBuscarCita";
            this.tbBuscarCita.SelectedText = "";
            this.tbBuscarCita.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarCita.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarCita.StyleManager = null;
            this.tbBuscarCita.TabIndex = 3;
            this.tbBuscarCita.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarCita.UseStyleColors = false;
            // 
            // dgvCitas
            // 
            this.dgvCitas.AllowUserToAddRows = false;
            this.dgvCitas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCitas.AutoGenerateColumns = false;
            this.dgvCitas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCitas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvCitas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCitas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.citaIDDataGridViewTextBoxColumn,
            this.ClienteID,
            this.NomCompletoClie,
            this.NomCompletoEmp,
            this.fechaDataGridViewTextBoxColumn,
            this.NombreServicio,
            this.costoDataGridViewTextBoxColumn1,
            this.telefonoDataGridViewTextBoxColumn2,
            this.descripcionDataGridViewTextBoxColumn1,
            this.Realizado});
            this.dgvCitas.DataSource = this.vistaCitasBindingSource;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCitas.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgvCitas.Location = new System.Drawing.Point(0, 65);
            this.dgvCitas.MultiSelect = false;
            this.dgvCitas.Name = "dgvCitas";
            this.dgvCitas.ReadOnly = true;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCitas.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCitas.RowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvCitas.RowTemplate.Height = 60;
            this.dgvCitas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCitas.Size = new System.Drawing.Size(1144, 299);
            this.dgvCitas.TabIndex = 2;
            this.dgvCitas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // citaIDDataGridViewTextBoxColumn
            // 
            this.citaIDDataGridViewTextBoxColumn.DataPropertyName = "CitaID";
            this.citaIDDataGridViewTextBoxColumn.HeaderText = "CitaID";
            this.citaIDDataGridViewTextBoxColumn.Name = "citaIDDataGridViewTextBoxColumn";
            this.citaIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.citaIDDataGridViewTextBoxColumn.Visible = false;
            this.citaIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // ClienteID
            // 
            this.ClienteID.DataPropertyName = "ClienteID";
            this.ClienteID.HeaderText = "Numero de Socio";
            this.ClienteID.Name = "ClienteID";
            this.ClienteID.ReadOnly = true;
            this.ClienteID.Width = 150;
            // 
            // NomCompletoClie
            // 
            this.NomCompletoClie.DataPropertyName = "NomCompletoClie";
            this.NomCompletoClie.HeaderText = "Nombre del Cliente";
            this.NomCompletoClie.Name = "NomCompletoClie";
            this.NomCompletoClie.ReadOnly = true;
            this.NomCompletoClie.Width = 150;
            // 
            // NomCompletoEmp
            // 
            this.NomCompletoEmp.DataPropertyName = "NomCompletoEmp";
            this.NomCompletoEmp.HeaderText = "Nombre del Empleado";
            this.NomCompletoEmp.Name = "NomCompletoEmp";
            this.NomCompletoEmp.ReadOnly = true;
            this.NomCompletoEmp.Width = 150;
            // 
            // fechaDataGridViewTextBoxColumn
            // 
            this.fechaDataGridViewTextBoxColumn.DataPropertyName = "Fecha";
            this.fechaDataGridViewTextBoxColumn.HeaderText = "Fecha de Cita";
            this.fechaDataGridViewTextBoxColumn.Name = "fechaDataGridViewTextBoxColumn";
            this.fechaDataGridViewTextBoxColumn.ReadOnly = true;
            this.fechaDataGridViewTextBoxColumn.Width = 150;
            // 
            // NombreServicio
            // 
            this.NombreServicio.DataPropertyName = "NombreServicio";
            this.NombreServicio.HeaderText = "Nombre del Servicio";
            this.NombreServicio.Name = "NombreServicio";
            this.NombreServicio.ReadOnly = true;
            this.NombreServicio.Width = 150;
            // 
            // costoDataGridViewTextBoxColumn1
            // 
            this.costoDataGridViewTextBoxColumn1.DataPropertyName = "Costo";
            this.costoDataGridViewTextBoxColumn1.HeaderText = "Costo";
            this.costoDataGridViewTextBoxColumn1.Name = "costoDataGridViewTextBoxColumn1";
            this.costoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // telefonoDataGridViewTextBoxColumn2
            // 
            this.telefonoDataGridViewTextBoxColumn2.DataPropertyName = "Telefono";
            this.telefonoDataGridViewTextBoxColumn2.HeaderText = "Telefono del Cliente";
            this.telefonoDataGridViewTextBoxColumn2.Name = "telefonoDataGridViewTextBoxColumn2";
            this.telefonoDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // descripcionDataGridViewTextBoxColumn1
            // 
            this.descripcionDataGridViewTextBoxColumn1.DataPropertyName = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn1.HeaderText = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn1.Name = "descripcionDataGridViewTextBoxColumn1";
            this.descripcionDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Realizado
            // 
            this.Realizado.DataPropertyName = "Realizado";
            this.Realizado.HeaderText = "Realizado";
            this.Realizado.Name = "Realizado";
            this.Realizado.ReadOnly = true;
            // 
            // vistaCitasBindingSource
            // 
            this.vistaCitasBindingSource.DataMember = "vistaCitas";
            this.vistaCitasBindingSource.DataSource = this.lucySpaDB;
            // 
            // tpAgenda
            // 
            this.tpAgenda.Controls.Add(this.monthViewAgenda);
            this.tpAgenda.Controls.Add(this.calendarAgenda);
            this.tpAgenda.CustomBackground = false;
            this.tpAgenda.HorizontalScrollbar = false;
            this.tpAgenda.HorizontalScrollbarBarColor = true;
            this.tpAgenda.HorizontalScrollbarHighlightOnWheel = false;
            this.tpAgenda.HorizontalScrollbarSize = 10;
            this.tpAgenda.Location = new System.Drawing.Point(4, 35);
            this.tpAgenda.Name = "tpAgenda";
            this.tpAgenda.Size = new System.Drawing.Size(1179, 441);
            this.tpAgenda.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpAgenda.StyleManager = null;
            this.tpAgenda.TabIndex = 10;
            this.tpAgenda.Text = "Agenda";
            this.tpAgenda.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpAgenda.VerticalScrollbar = false;
            this.tpAgenda.VerticalScrollbarBarColor = true;
            this.tpAgenda.VerticalScrollbarHighlightOnWheel = false;
            this.tpAgenda.VerticalScrollbarSize = 10;
            // 
            // monthViewAgenda
            // 
            this.monthViewAgenda.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.monthViewAgenda.ArrowsColor = System.Drawing.SystemColors.Window;
            this.monthViewAgenda.ArrowsSelectedColor = System.Drawing.Color.Gold;
            this.monthViewAgenda.DayBackgroundColor = System.Drawing.Color.Empty;
            this.monthViewAgenda.DayGrayedText = System.Drawing.SystemColors.GrayText;
            this.monthViewAgenda.DaySelectedBackgroundColor = System.Drawing.SystemColors.Highlight;
            this.monthViewAgenda.DaySelectedColor = System.Drawing.SystemColors.WindowText;
            this.monthViewAgenda.DaySelectedTextColor = System.Drawing.SystemColors.HighlightText;
            this.monthViewAgenda.ItemPadding = new System.Windows.Forms.Padding(2);
            this.monthViewAgenda.Location = new System.Drawing.Point(-4, 0);
            this.monthViewAgenda.MonthTitleColor = System.Drawing.SystemColors.ActiveCaption;
            this.monthViewAgenda.MonthTitleColorInactive = System.Drawing.SystemColors.InactiveCaption;
            this.monthViewAgenda.MonthTitleTextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.monthViewAgenda.MonthTitleTextColorInactive = System.Drawing.SystemColors.InactiveCaptionText;
            this.monthViewAgenda.Name = "monthViewAgenda";
            this.monthViewAgenda.Size = new System.Drawing.Size(231, 433);
            this.monthViewAgenda.TabIndex = 3;
            this.monthViewAgenda.Text = "monthView1";
            this.monthViewAgenda.TodayBorderColor = System.Drawing.Color.Maroon;
            this.monthViewAgenda.SelectionChanged += new System.EventHandler(this.monthViewAgenda_SelectionChanged);
            // 
            // calendarAgenda
            // 
            this.calendarAgenda.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.calendarAgenda.Font = new System.Drawing.Font("Segoe UI", 9F);
            calendarHighlightRange1.DayOfWeek = System.DayOfWeek.Monday;
            calendarHighlightRange1.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange1.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange2.DayOfWeek = System.DayOfWeek.Tuesday;
            calendarHighlightRange2.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange2.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange3.DayOfWeek = System.DayOfWeek.Wednesday;
            calendarHighlightRange3.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange3.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange4.DayOfWeek = System.DayOfWeek.Thursday;
            calendarHighlightRange4.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange4.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange5.DayOfWeek = System.DayOfWeek.Friday;
            calendarHighlightRange5.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange5.StartTime = System.TimeSpan.Parse("08:00:00");
            this.calendarAgenda.HighlightRanges = new System.Windows.Forms.Calendar.CalendarHighlightRange[] {
        calendarHighlightRange1,
        calendarHighlightRange2,
        calendarHighlightRange3,
        calendarHighlightRange4,
        calendarHighlightRange5};
            this.calendarAgenda.Location = new System.Drawing.Point(233, 3);
            this.calendarAgenda.Name = "calendarAgenda";
            this.calendarAgenda.Size = new System.Drawing.Size(911, 423);
            this.calendarAgenda.TabIndex = 2;
            this.calendarAgenda.Text = "calendar1";
            this.calendarAgenda.ItemDoubleClick += new System.Windows.Forms.Calendar.Calendar.CalendarItemEventHandler(this.calendarAgenda_ItemDoubleClick);
            // 
            // tpTarjetas
            // 
            this.tpTarjetas.Controls.Add(this.tbNuevasTarjetas);
            this.tpTarjetas.Controls.Add(this.tbTarjetasLibres);
            this.tpTarjetas.Controls.Add(this.tbTarjetasAsignadas);
            this.tpTarjetas.Controls.Add(this.tbCantidadTarjetas);
            this.tpTarjetas.Controls.Add(this.tbCostoTarjetas);
            this.tpTarjetas.Controls.Add(this.lblNuevaTarjetas);
            this.tpTarjetas.Controls.Add(this.lblTarjetasLibres);
            this.tpTarjetas.Controls.Add(this.lblCantidadTarjetas);
            this.tpTarjetas.Controls.Add(this.lblTarjetasAsignadas);
            this.tpTarjetas.Controls.Add(this.lblCostoTarjeta);
            this.tpTarjetas.Controls.Add(this.btnBuscarTarjetas);
            this.tpTarjetas.Controls.Add(this.btnBorrarTarjeta);
            this.tpTarjetas.Controls.Add(this.btnModificarCostoTarjeta);
            this.tpTarjetas.Controls.Add(this.tbBuscarTarjeta);
            this.tpTarjetas.Controls.Add(this.btnAgregarTarjeta);
            this.tpTarjetas.Controls.Add(this.dgvTarjetas);
            this.tpTarjetas.CustomBackground = false;
            this.tpTarjetas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpTarjetas.HorizontalScrollbar = false;
            this.tpTarjetas.HorizontalScrollbarBarColor = true;
            this.tpTarjetas.HorizontalScrollbarHighlightOnWheel = false;
            this.tpTarjetas.HorizontalScrollbarSize = 10;
            this.tpTarjetas.Location = new System.Drawing.Point(4, 35);
            this.tpTarjetas.Name = "tpTarjetas";
            this.tpTarjetas.Size = new System.Drawing.Size(1179, 441);
            this.tpTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpTarjetas.StyleManager = null;
            this.tpTarjetas.TabIndex = 7;
            this.tpTarjetas.Text = "Tarjetas";
            this.tpTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpTarjetas.VerticalScrollbar = false;
            this.tpTarjetas.VerticalScrollbarBarColor = true;
            this.tpTarjetas.VerticalScrollbarHighlightOnWheel = false;
            this.tpTarjetas.VerticalScrollbarSize = 10;
            this.tpTarjetas.Click += new System.EventHandler(this.tpTarjetas_Click);
            // 
            // tbNuevasTarjetas
            // 
            this.tbNuevasTarjetas.CustomBackground = false;
            this.tbNuevasTarjetas.CustomForeColor = false;
            this.tbNuevasTarjetas.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbNuevasTarjetas.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbNuevasTarjetas.Location = new System.Drawing.Point(191, 226);
            this.tbNuevasTarjetas.Multiline = false;
            this.tbNuevasTarjetas.Name = "tbNuevasTarjetas";
            this.tbNuevasTarjetas.SelectedText = "";
            this.tbNuevasTarjetas.Size = new System.Drawing.Size(187, 40);
            this.tbNuevasTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbNuevasTarjetas.StyleManager = null;
            this.tbNuevasTarjetas.TabIndex = 25;
            this.tbNuevasTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbNuevasTarjetas.UseStyleColors = false;
            // 
            // tbTarjetasLibres
            // 
            this.tbTarjetasLibres.CustomBackground = false;
            this.tbTarjetasLibres.CustomForeColor = false;
            this.tbTarjetasLibres.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbTarjetasLibres.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbTarjetasLibres.Location = new System.Drawing.Point(191, 180);
            this.tbTarjetasLibres.Multiline = false;
            this.tbTarjetasLibres.Name = "tbTarjetasLibres";
            this.tbTarjetasLibres.SelectedText = "";
            this.tbTarjetasLibres.Size = new System.Drawing.Size(187, 40);
            this.tbTarjetasLibres.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbTarjetasLibres.StyleManager = null;
            this.tbTarjetasLibres.TabIndex = 24;
            this.tbTarjetasLibres.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbTarjetasLibres.UseStyleColors = false;
            // 
            // tbTarjetasAsignadas
            // 
            this.tbTarjetasAsignadas.CustomBackground = false;
            this.tbTarjetasAsignadas.CustomForeColor = false;
            this.tbTarjetasAsignadas.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbTarjetasAsignadas.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbTarjetasAsignadas.Location = new System.Drawing.Point(191, 134);
            this.tbTarjetasAsignadas.Multiline = false;
            this.tbTarjetasAsignadas.Name = "tbTarjetasAsignadas";
            this.tbTarjetasAsignadas.SelectedText = "";
            this.tbTarjetasAsignadas.Size = new System.Drawing.Size(187, 40);
            this.tbTarjetasAsignadas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbTarjetasAsignadas.StyleManager = null;
            this.tbTarjetasAsignadas.TabIndex = 23;
            this.tbTarjetasAsignadas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbTarjetasAsignadas.UseStyleColors = false;
            // 
            // tbCantidadTarjetas
            // 
            this.tbCantidadTarjetas.CustomBackground = false;
            this.tbCantidadTarjetas.CustomForeColor = false;
            this.tbCantidadTarjetas.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbCantidadTarjetas.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbCantidadTarjetas.Location = new System.Drawing.Point(191, 88);
            this.tbCantidadTarjetas.Multiline = false;
            this.tbCantidadTarjetas.Name = "tbCantidadTarjetas";
            this.tbCantidadTarjetas.SelectedText = "";
            this.tbCantidadTarjetas.Size = new System.Drawing.Size(187, 40);
            this.tbCantidadTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbCantidadTarjetas.StyleManager = null;
            this.tbCantidadTarjetas.TabIndex = 22;
            this.tbCantidadTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbCantidadTarjetas.UseStyleColors = false;
            // 
            // tbCostoTarjetas
            // 
            this.tbCostoTarjetas.CustomBackground = false;
            this.tbCostoTarjetas.CustomForeColor = false;
            this.tbCostoTarjetas.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbCostoTarjetas.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbCostoTarjetas.Location = new System.Drawing.Point(191, 42);
            this.tbCostoTarjetas.Multiline = false;
            this.tbCostoTarjetas.Name = "tbCostoTarjetas";
            this.tbCostoTarjetas.SelectedText = "";
            this.tbCostoTarjetas.Size = new System.Drawing.Size(187, 40);
            this.tbCostoTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbCostoTarjetas.StyleManager = null;
            this.tbCostoTarjetas.TabIndex = 21;
            this.tbCostoTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbCostoTarjetas.UseStyleColors = false;
            // 
            // lblNuevaTarjetas
            // 
            this.lblNuevaTarjetas.AutoSize = true;
            this.lblNuevaTarjetas.CustomBackground = false;
            this.lblNuevaTarjetas.CustomForeColor = false;
            this.lblNuevaTarjetas.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblNuevaTarjetas.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.lblNuevaTarjetas.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblNuevaTarjetas.Location = new System.Drawing.Point(0, 234);
            this.lblNuevaTarjetas.Name = "lblNuevaTarjetas";
            this.lblNuevaTarjetas.Size = new System.Drawing.Size(191, 25);
            this.lblNuevaTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblNuevaTarjetas.StyleManager = null;
            this.lblNuevaTarjetas.TabIndex = 20;
            this.lblNuevaTarjetas.Text = "Agregar/Borrar Tarjetas:";
            this.lblNuevaTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblNuevaTarjetas.UseStyleColors = false;
            // 
            // lblTarjetasLibres
            // 
            this.lblTarjetasLibres.AutoSize = true;
            this.lblTarjetasLibres.CustomBackground = false;
            this.lblTarjetasLibres.CustomForeColor = false;
            this.lblTarjetasLibres.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblTarjetasLibres.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.lblTarjetasLibres.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblTarjetasLibres.Location = new System.Drawing.Point(-4, 188);
            this.lblTarjetasLibres.Name = "lblTarjetasLibres";
            this.lblTarjetasLibres.Size = new System.Drawing.Size(120, 25);
            this.lblTarjetasLibres.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblTarjetasLibres.StyleManager = null;
            this.lblTarjetasLibres.TabIndex = 19;
            this.lblTarjetasLibres.Text = "Tarjetas Libres:";
            this.lblTarjetasLibres.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblTarjetasLibres.UseStyleColors = false;
            // 
            // lblCantidadTarjetas
            // 
            this.lblCantidadTarjetas.AutoSize = true;
            this.lblCantidadTarjetas.CustomBackground = false;
            this.lblCantidadTarjetas.CustomForeColor = false;
            this.lblCantidadTarjetas.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblCantidadTarjetas.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.lblCantidadTarjetas.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblCantidadTarjetas.Location = new System.Drawing.Point(-4, 96);
            this.lblCantidadTarjetas.Name = "lblCantidadTarjetas";
            this.lblCantidadTarjetas.Size = new System.Drawing.Size(144, 25);
            this.lblCantidadTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblCantidadTarjetas.StyleManager = null;
            this.lblCantidadTarjetas.TabIndex = 18;
            this.lblCantidadTarjetas.Text = "Cantidad Tarjetas:";
            this.lblCantidadTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblCantidadTarjetas.UseStyleColors = false;
            // 
            // lblTarjetasAsignadas
            // 
            this.lblTarjetasAsignadas.AutoSize = true;
            this.lblTarjetasAsignadas.CustomBackground = false;
            this.lblTarjetasAsignadas.CustomForeColor = false;
            this.lblTarjetasAsignadas.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblTarjetasAsignadas.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.lblTarjetasAsignadas.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblTarjetasAsignadas.Location = new System.Drawing.Point(-4, 142);
            this.lblTarjetasAsignadas.Name = "lblTarjetasAsignadas";
            this.lblTarjetasAsignadas.Size = new System.Drawing.Size(153, 25);
            this.lblTarjetasAsignadas.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblTarjetasAsignadas.StyleManager = null;
            this.lblTarjetasAsignadas.TabIndex = 17;
            this.lblTarjetasAsignadas.Text = "Tarjetas Asignadas:";
            this.lblTarjetasAsignadas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblTarjetasAsignadas.UseStyleColors = false;
            // 
            // lblCostoTarjeta
            // 
            this.lblCostoTarjeta.AutoSize = true;
            this.lblCostoTarjeta.CustomBackground = false;
            this.lblCostoTarjeta.CustomForeColor = false;
            this.lblCostoTarjeta.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.lblCostoTarjeta.FontWeight = MetroFramework.MetroLabelWeight.Light;
            this.lblCostoTarjeta.LabelMode = MetroFramework.Controls.MetroLabelMode.Default;
            this.lblCostoTarjeta.Location = new System.Drawing.Point(-4, 50);
            this.lblCostoTarjeta.Name = "lblCostoTarjeta";
            this.lblCostoTarjeta.Size = new System.Drawing.Size(143, 25);
            this.lblCostoTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.lblCostoTarjeta.StyleManager = null;
            this.lblCostoTarjeta.TabIndex = 16;
            this.lblCostoTarjeta.Text = "Costo de Tarjetas:";
            this.lblCostoTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblCostoTarjeta.UseStyleColors = false;
            // 
            // btnBuscarTarjetas
            // 
            this.btnBuscarTarjetas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarTarjetas.Highlight = false;
            this.btnBuscarTarjetas.Location = new System.Drawing.Point(820, 42);
            this.btnBuscarTarjetas.Name = "btnBuscarTarjetas";
            this.btnBuscarTarjetas.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarTarjetas.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarTarjetas.StyleManager = null;
            this.btnBuscarTarjetas.TabIndex = 15;
            this.btnBuscarTarjetas.Text = "Buscar..";
            this.btnBuscarTarjetas.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarTarjetas.Click += new System.EventHandler(this.btnBuscarTarjetas_Click);
            // 
            // btnBorrarTarjeta
            // 
            this.btnBorrarTarjeta.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarTarjeta.Highlight = false;
            this.btnBorrarTarjeta.Location = new System.Drawing.Point(597, 366);
            this.btnBorrarTarjeta.Name = "btnBorrarTarjeta";
            this.btnBorrarTarjeta.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarTarjeta.StyleManager = null;
            this.btnBorrarTarjeta.TabIndex = 14;
            this.btnBorrarTarjeta.Text = "Borrar";
            this.btnBorrarTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarTarjeta.Click += new System.EventHandler(this.btnBorrarTarjeta_Click);
            // 
            // btnModificarCostoTarjeta
            // 
            this.btnModificarCostoTarjeta.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarCostoTarjeta.Highlight = false;
            this.btnModificarCostoTarjeta.Location = new System.Drawing.Point(382, 366);
            this.btnModificarCostoTarjeta.Name = "btnModificarCostoTarjeta";
            this.btnModificarCostoTarjeta.Size = new System.Drawing.Size(180, 60);
            this.btnModificarCostoTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarCostoTarjeta.StyleManager = null;
            this.btnModificarCostoTarjeta.TabIndex = 13;
            this.btnModificarCostoTarjeta.Text = "Cambiar Costo de Tarjetas";
            this.btnModificarCostoTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarCostoTarjeta.Click += new System.EventHandler(this.btnModificarCostoTarjeta_Click);
            // 
            // tbBuscarTarjeta
            // 
            this.tbBuscarTarjeta.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarTarjeta.CustomBackground = false;
            this.tbBuscarTarjeta.CustomForeColor = false;
            this.tbBuscarTarjeta.FontSize = MetroFramework.MetroTextBoxSize.Tall;
            this.tbBuscarTarjeta.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarTarjeta.Location = new System.Drawing.Point(434, 42);
            this.tbBuscarTarjeta.Multiline = false;
            this.tbBuscarTarjeta.Name = "tbBuscarTarjeta";
            this.tbBuscarTarjeta.SelectedText = "";
            this.tbBuscarTarjeta.Size = new System.Drawing.Size(380, 40);
            this.tbBuscarTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarTarjeta.StyleManager = null;
            this.tbBuscarTarjeta.TabIndex = 12;
            this.tbBuscarTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarTarjeta.UseStyleColors = false;
            // 
            // btnAgregarTarjeta
            // 
            this.btnAgregarTarjeta.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarTarjeta.Highlight = false;
            this.btnAgregarTarjeta.Location = new System.Drawing.Point(166, 366);
            this.btnAgregarTarjeta.Name = "btnAgregarTarjeta";
            this.btnAgregarTarjeta.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarTarjeta.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarTarjeta.StyleManager = null;
            this.btnAgregarTarjeta.TabIndex = 11;
            this.btnAgregarTarjeta.Text = "Agregar";
            this.btnAgregarTarjeta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarTarjeta.Click += new System.EventHandler(this.btnAgregarTarjeta_Click);
            // 
            // dgvTarjetas
            // 
            this.dgvTarjetas.AllowUserToAddRows = false;
            this.dgvTarjetas.AllowUserToDeleteRows = false;
            this.dgvTarjetas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTarjetas.AutoGenerateColumns = false;
            this.dgvTarjetas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTarjetas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tarjetaIDDataGridViewTextBoxColumn,
            this.nombreCompletoDataGridViewTextBoxColumn,
            this.fecchaCompraDataGridViewTextBoxColumn});
            this.dgvTarjetas.DataSource = this.vistaClientesConTarjetasBindingSource;
            this.dgvTarjetas.Location = new System.Drawing.Point(434, 88);
            this.dgvTarjetas.Name = "dgvTarjetas";
            this.dgvTarjetas.ReadOnly = true;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTarjetas.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvTarjetas.RowTemplate.Height = 60;
            this.dgvTarjetas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTarjetas.Size = new System.Drawing.Size(526, 212);
            this.dgvTarjetas.TabIndex = 10;
            // 
            // tarjetaIDDataGridViewTextBoxColumn
            // 
            this.tarjetaIDDataGridViewTextBoxColumn.DataPropertyName = "TarjetaID";
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tarjetaIDDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle27;
            this.tarjetaIDDataGridViewTextBoxColumn.HeaderText = "Numero de Tarjeta";
            this.tarjetaIDDataGridViewTextBoxColumn.Name = "tarjetaIDDataGridViewTextBoxColumn";
            this.tarjetaIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreCompletoDataGridViewTextBoxColumn
            // 
            this.nombreCompletoDataGridViewTextBoxColumn.DataPropertyName = "nombreCompleto";
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombreCompletoDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle28;
            this.nombreCompletoDataGridViewTextBoxColumn.HeaderText = "Nombre del Clientte";
            this.nombreCompletoDataGridViewTextBoxColumn.Name = "nombreCompletoDataGridViewTextBoxColumn";
            this.nombreCompletoDataGridViewTextBoxColumn.ReadOnly = true;
            this.nombreCompletoDataGridViewTextBoxColumn.Width = 300;
            // 
            // fecchaCompraDataGridViewTextBoxColumn
            // 
            this.fecchaCompraDataGridViewTextBoxColumn.DataPropertyName = "FecchaCompra";
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fecchaCompraDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle29;
            this.fecchaCompraDataGridViewTextBoxColumn.HeaderText = "Feccha de Compra";
            this.fecchaCompraDataGridViewTextBoxColumn.Name = "fecchaCompraDataGridViewTextBoxColumn";
            this.fecchaCompraDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // vistaClientesConTarjetasBindingSource
            // 
            this.vistaClientesConTarjetasBindingSource.DataMember = "VistaClientesConTarjetas";
            this.vistaClientesConTarjetasBindingSource.DataSource = this.dSTarjetas;
            // 
            // dSTarjetas
            // 
            this.dSTarjetas.DataSetName = "DSTarjetas";
            this.dSTarjetas.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tpProductos
            // 
            this.tpProductos.Controls.Add(this.btnBuscarProducto);
            this.tpProductos.Controls.Add(this.btnBorrarProductos);
            this.tpProductos.Controls.Add(this.btnModificarProductos);
            this.tpProductos.Controls.Add(this.tbBuscarProductos);
            this.tpProductos.Controls.Add(this.btnAgregarProductos);
            this.tpProductos.Controls.Add(this.dgvProductos);
            this.tpProductos.CustomBackground = false;
            this.tpProductos.HorizontalScrollbar = false;
            this.tpProductos.HorizontalScrollbarBarColor = true;
            this.tpProductos.HorizontalScrollbarHighlightOnWheel = false;
            this.tpProductos.HorizontalScrollbarSize = 10;
            this.tpProductos.Location = new System.Drawing.Point(4, 35);
            this.tpProductos.Name = "tpProductos";
            this.tpProductos.Size = new System.Drawing.Size(1179, 441);
            this.tpProductos.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpProductos.StyleManager = null;
            this.tpProductos.TabIndex = 8;
            this.tpProductos.Text = "Productos";
            this.tpProductos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpProductos.VerticalScrollbar = false;
            this.tpProductos.VerticalScrollbarBarColor = true;
            this.tpProductos.VerticalScrollbarHighlightOnWheel = false;
            this.tpProductos.VerticalScrollbarSize = 10;
            // 
            // btnBuscarProducto
            // 
            this.btnBuscarProducto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarProducto.Highlight = false;
            this.btnBuscarProducto.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscarProducto.Name = "btnBuscarProducto";
            this.btnBuscarProducto.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarProducto.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarProducto.StyleManager = null;
            this.btnBuscarProducto.TabIndex = 15;
            this.btnBuscarProducto.Text = "Buscar..";
            this.btnBuscarProducto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarProducto.Click += new System.EventHandler(this.btnBuscarProducto_Click);
            // 
            // btnBorrarProductos
            // 
            this.btnBorrarProductos.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarProductos.Highlight = false;
            this.btnBorrarProductos.Location = new System.Drawing.Point(597, 366);
            this.btnBorrarProductos.Name = "btnBorrarProductos";
            this.btnBorrarProductos.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarProductos.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarProductos.StyleManager = null;
            this.btnBorrarProductos.TabIndex = 14;
            this.btnBorrarProductos.Text = "Borrar";
            this.btnBorrarProductos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarProductos.Click += new System.EventHandler(this.btnBorrarProductos_Click);
            // 
            // btnModificarProductos
            // 
            this.btnModificarProductos.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarProductos.Highlight = false;
            this.btnModificarProductos.Location = new System.Drawing.Point(391, 366);
            this.btnModificarProductos.Name = "btnModificarProductos";
            this.btnModificarProductos.Size = new System.Drawing.Size(180, 60);
            this.btnModificarProductos.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarProductos.StyleManager = null;
            this.btnModificarProductos.TabIndex = 13;
            this.btnModificarProductos.Text = "Modificar";
            this.btnModificarProductos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarProductos.Click += new System.EventHandler(this.btnModificarProductos_Click);
            // 
            // tbBuscarProductos
            // 
            this.tbBuscarProductos.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarProductos.CustomBackground = false;
            this.tbBuscarProductos.CustomForeColor = false;
            this.tbBuscarProductos.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarProductos.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarProductos.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarProductos.Multiline = false;
            this.tbBuscarProductos.Name = "tbBuscarProductos";
            this.tbBuscarProductos.SelectedText = "";
            this.tbBuscarProductos.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarProductos.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarProductos.StyleManager = null;
            this.tbBuscarProductos.TabIndex = 12;
            this.tbBuscarProductos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarProductos.UseStyleColors = false;
            // 
            // btnAgregarProductos
            // 
            this.btnAgregarProductos.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarProductos.Highlight = false;
            this.btnAgregarProductos.Location = new System.Drawing.Point(166, 366);
            this.btnAgregarProductos.Name = "btnAgregarProductos";
            this.btnAgregarProductos.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarProductos.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarProductos.StyleManager = null;
            this.btnAgregarProductos.TabIndex = 11;
            this.btnAgregarProductos.Text = "Agregar";
            this.btnAgregarProductos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarProductos.Click += new System.EventHandler(this.btnAgregarProductos_Click);
            // 
            // dgvProductos
            // 
            this.dgvProductos.AllowUserToAddRows = false;
            this.dgvProductos.AllowUserToDeleteRows = false;
            this.dgvProductos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvProductos.AutoGenerateColumns = false;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProductos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productoIDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn6,
            this.precioDataGridViewTextBoxColumn,
            this.costoDataGridViewTextBoxColumn3,
            this.cantidadDataGridViewTextBoxColumn,
            this.descripcionDataGridViewTextBoxColumn4});
            this.dgvProductos.DataSource = this.productosBindingSource;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProductos.DefaultCellStyle = dataGridViewCellStyle32;
            this.dgvProductos.Location = new System.Drawing.Point(0, 65);
            this.dgvProductos.MultiSelect = false;
            this.dgvProductos.Name = "dgvProductos";
            this.dgvProductos.ReadOnly = true;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvProductos.RowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvProductos.RowTemplate.Height = 60;
            this.dgvProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProductos.Size = new System.Drawing.Size(1144, 282);
            this.dgvProductos.TabIndex = 10;
            // 
            // productoIDDataGridViewTextBoxColumn
            // 
            this.productoIDDataGridViewTextBoxColumn.DataPropertyName = "ProductoID";
            this.productoIDDataGridViewTextBoxColumn.HeaderText = "ProductoID";
            this.productoIDDataGridViewTextBoxColumn.Name = "productoIDDataGridViewTextBoxColumn";
            this.productoIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn6
            // 
            this.nombreDataGridViewTextBoxColumn6.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn6.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn6.Name = "nombreDataGridViewTextBoxColumn6";
            this.nombreDataGridViewTextBoxColumn6.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn6.Width = 200;
            // 
            // precioDataGridViewTextBoxColumn
            // 
            this.precioDataGridViewTextBoxColumn.DataPropertyName = "Precio";
            this.precioDataGridViewTextBoxColumn.HeaderText = "Precio";
            this.precioDataGridViewTextBoxColumn.Name = "precioDataGridViewTextBoxColumn";
            this.precioDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // costoDataGridViewTextBoxColumn3
            // 
            this.costoDataGridViewTextBoxColumn3.DataPropertyName = "Costo";
            this.costoDataGridViewTextBoxColumn3.HeaderText = "Costo";
            this.costoDataGridViewTextBoxColumn3.Name = "costoDataGridViewTextBoxColumn3";
            this.costoDataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // cantidadDataGridViewTextBoxColumn
            // 
            this.cantidadDataGridViewTextBoxColumn.DataPropertyName = "Cantidad";
            this.cantidadDataGridViewTextBoxColumn.HeaderText = "Cantidad";
            this.cantidadDataGridViewTextBoxColumn.Name = "cantidadDataGridViewTextBoxColumn";
            this.cantidadDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descripcionDataGridViewTextBoxColumn4
            // 
            this.descripcionDataGridViewTextBoxColumn4.DataPropertyName = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn4.HeaderText = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn4.Name = "descripcionDataGridViewTextBoxColumn4";
            this.descripcionDataGridViewTextBoxColumn4.ReadOnly = true;
            this.descripcionDataGridViewTextBoxColumn4.Width = 500;
            // 
            // productosBindingSource
            // 
            this.productosBindingSource.DataMember = "Productos";
            this.productosBindingSource.DataSource = this.lucySpaDB;
            // 
            // tpCuartos
            // 
            this.tpCuartos.Controls.Add(this.btnRelacionCuartoServicios);
            this.tpCuartos.Controls.Add(this.btnModificar);
            this.tpCuartos.Controls.Add(this.btnBuscarCuarto);
            this.tpCuartos.Controls.Add(this.btnNuevoCuarto);
            this.tpCuartos.Controls.Add(this.btnBorrarCuarto);
            this.tpCuartos.Controls.Add(this.tbBuscarCuarto);
            this.tpCuartos.Controls.Add(this.dgvCuartos);
            this.tpCuartos.CustomBackground = false;
            this.tpCuartos.HorizontalScrollbar = false;
            this.tpCuartos.HorizontalScrollbarBarColor = true;
            this.tpCuartos.HorizontalScrollbarHighlightOnWheel = false;
            this.tpCuartos.HorizontalScrollbarSize = 10;
            this.tpCuartos.Location = new System.Drawing.Point(4, 35);
            this.tpCuartos.Name = "tpCuartos";
            this.tpCuartos.Size = new System.Drawing.Size(1179, 441);
            this.tpCuartos.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpCuartos.StyleManager = null;
            this.tpCuartos.TabIndex = 9;
            this.tpCuartos.Text = "Cuartos";
            this.tpCuartos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpCuartos.VerticalScrollbar = false;
            this.tpCuartos.VerticalScrollbarBarColor = true;
            this.tpCuartos.VerticalScrollbarHighlightOnWheel = false;
            this.tpCuartos.VerticalScrollbarSize = 10;
            this.tpCuartos.Click += new System.EventHandler(this.tpCuartos_Click);
            // 
            // btnRelacionCuartoServicios
            // 
            this.btnRelacionCuartoServicios.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnRelacionCuartoServicios.Highlight = false;
            this.btnRelacionCuartoServicios.Location = new System.Drawing.Point(724, 366);
            this.btnRelacionCuartoServicios.Name = "btnRelacionCuartoServicios";
            this.btnRelacionCuartoServicios.Size = new System.Drawing.Size(180, 60);
            this.btnRelacionCuartoServicios.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnRelacionCuartoServicios.StyleManager = null;
            this.btnRelacionCuartoServicios.TabIndex = 23;
            this.btnRelacionCuartoServicios.Text = "Relacion con Servicios";
            this.btnRelacionCuartoServicios.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnRelacionCuartoServicios.Click += new System.EventHandler(this.btnRelacionCuartoServicios_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificar.Highlight = false;
            this.btnModificar.Location = new System.Drawing.Point(317, 366);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(180, 60);
            this.btnModificar.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificar.StyleManager = null;
            this.btnModificar.TabIndex = 22;
            this.btnModificar.Text = "Modificar";
            this.btnModificar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnBuscarCuarto
            // 
            this.btnBuscarCuarto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarCuarto.Highlight = false;
            this.btnBuscarCuarto.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscarCuarto.Name = "btnBuscarCuarto";
            this.btnBuscarCuarto.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarCuarto.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarCuarto.StyleManager = null;
            this.btnBuscarCuarto.TabIndex = 21;
            this.btnBuscarCuarto.Text = "Buscar..";
            this.btnBuscarCuarto.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // btnNuevoCuarto
            // 
            this.btnNuevoCuarto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnNuevoCuarto.Highlight = false;
            this.btnNuevoCuarto.Location = new System.Drawing.Point(92, 366);
            this.btnNuevoCuarto.Name = "btnNuevoCuarto";
            this.btnNuevoCuarto.Size = new System.Drawing.Size(180, 60);
            this.btnNuevoCuarto.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnNuevoCuarto.StyleManager = null;
            this.btnNuevoCuarto.TabIndex = 20;
            this.btnNuevoCuarto.Text = "Agregar Cuarto";
            this.btnNuevoCuarto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnNuevoCuarto.Click += new System.EventHandler(this.btnNuevoCuarto_Click);
            // 
            // btnBorrarCuarto
            // 
            this.btnBorrarCuarto.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarCuarto.Highlight = false;
            this.btnBorrarCuarto.Location = new System.Drawing.Point(523, 366);
            this.btnBorrarCuarto.Name = "btnBorrarCuarto";
            this.btnBorrarCuarto.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarCuarto.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarCuarto.StyleManager = null;
            this.btnBorrarCuarto.TabIndex = 19;
            this.btnBorrarCuarto.Text = "Borrar";
            this.btnBorrarCuarto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarCuarto.Click += new System.EventHandler(this.btnBorrarCuarto_Click);
            // 
            // tbBuscarCuarto
            // 
            this.tbBuscarCuarto.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarCuarto.CustomBackground = false;
            this.tbBuscarCuarto.CustomForeColor = false;
            this.tbBuscarCuarto.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarCuarto.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarCuarto.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarCuarto.Multiline = false;
            this.tbBuscarCuarto.Name = "tbBuscarCuarto";
            this.tbBuscarCuarto.SelectedText = "";
            this.tbBuscarCuarto.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarCuarto.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarCuarto.StyleManager = null;
            this.tbBuscarCuarto.TabIndex = 17;
            this.tbBuscarCuarto.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarCuarto.UseStyleColors = false;
            // 
            // dgvCuartos
            // 
            this.dgvCuartos.AllowUserToAddRows = false;
            this.dgvCuartos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCuartos.AutoGenerateColumns = false;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCuartos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvCuartos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCuartos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnaNumeroCuarto,
            this.ColumnaNombreCuarto,
            this.ColumnaDescripcionCuarto});
            this.dgvCuartos.DataSource = this.cuartoBindingSource;
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCuartos.DefaultCellStyle = dataGridViewCellStyle35;
            this.dgvCuartos.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvCuartos.Location = new System.Drawing.Point(0, 65);
            this.dgvCuartos.MultiSelect = false;
            this.dgvCuartos.Name = "dgvCuartos";
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCuartos.RowsDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvCuartos.RowTemplate.Height = 60;
            this.dgvCuartos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCuartos.Size = new System.Drawing.Size(1144, 282);
            this.dgvCuartos.TabIndex = 15;
            this.dgvCuartos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCuartos_CellClick);
            this.dgvCuartos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCuartos_CellContentClick);
            this.dgvCuartos.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCuartos_CellEndEdit);
            this.dgvCuartos.UserDeletedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvCuartos_UserDeletedRow);
            this.dgvCuartos.RegionChanged += new System.EventHandler(this.dgvCuartos_RegionChanged);
            this.dgvCuartos.Click += new System.EventHandler(this.dgvCuartos_Click);
            // 
            // ColumnaNumeroCuarto
            // 
            this.ColumnaNumeroCuarto.DataPropertyName = "CuartoID";
            this.ColumnaNumeroCuarto.HeaderText = "Numero de Cuarto";
            this.ColumnaNumeroCuarto.Name = "ColumnaNumeroCuarto";
            this.ColumnaNumeroCuarto.ReadOnly = true;
            this.ColumnaNumeroCuarto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnaNombreCuarto
            // 
            this.ColumnaNombreCuarto.DataPropertyName = "Nombre";
            this.ColumnaNombreCuarto.HeaderText = "Nombre";
            this.ColumnaNombreCuarto.Name = "ColumnaNombreCuarto";
            this.ColumnaNombreCuarto.ReadOnly = true;
            this.ColumnaNombreCuarto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumnaNombreCuarto.Width = 150;
            // 
            // ColumnaDescripcionCuarto
            // 
            this.ColumnaDescripcionCuarto.DataPropertyName = "Descripcion";
            this.ColumnaDescripcionCuarto.HeaderText = "Descripcion";
            this.ColumnaDescripcionCuarto.Name = "ColumnaDescripcionCuarto";
            this.ColumnaDescripcionCuarto.ReadOnly = true;
            this.ColumnaDescripcionCuarto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumnaDescripcionCuarto.Width = 500;
            // 
            // cuartoBindingSource
            // 
            this.cuartoBindingSource.DataMember = "Cuarto";
            this.cuartoBindingSource.DataSource = this.lucySpaDB;
            // 
            // tpEquipo
            // 
            this.tpEquipo.Controls.Add(this.btnBorrarEquipo);
            this.tpEquipo.Controls.Add(this.btnModificarEquipo);
            this.tpEquipo.Controls.Add(this.btnAgregarEquipo);
            this.tpEquipo.Controls.Add(this.btnBuscarEquipo);
            this.tpEquipo.Controls.Add(this.tbBuscarEquipo);
            this.tpEquipo.Controls.Add(this.dgvEquipo);
            this.tpEquipo.CustomBackground = false;
            this.tpEquipo.HorizontalScrollbar = false;
            this.tpEquipo.HorizontalScrollbarBarColor = true;
            this.tpEquipo.HorizontalScrollbarHighlightOnWheel = false;
            this.tpEquipo.HorizontalScrollbarSize = 10;
            this.tpEquipo.Location = new System.Drawing.Point(4, 35);
            this.tpEquipo.Name = "tpEquipo";
            this.tpEquipo.Size = new System.Drawing.Size(1179, 441);
            this.tpEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpEquipo.StyleManager = null;
            this.tpEquipo.TabIndex = 11;
            this.tpEquipo.Text = "Equipo";
            this.tpEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpEquipo.VerticalScrollbar = false;
            this.tpEquipo.VerticalScrollbarBarColor = true;
            this.tpEquipo.VerticalScrollbarHighlightOnWheel = false;
            this.tpEquipo.VerticalScrollbarSize = 10;
            this.tpEquipo.Click += new System.EventHandler(this.tpEquipo_Click);
            // 
            // btnBorrarEquipo
            // 
            this.btnBorrarEquipo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnBorrarEquipo.Highlight = false;
            this.btnBorrarEquipo.Location = new System.Drawing.Point(597, 366);
            this.btnBorrarEquipo.Name = "btnBorrarEquipo";
            this.btnBorrarEquipo.Size = new System.Drawing.Size(180, 60);
            this.btnBorrarEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarEquipo.StyleManager = null;
            this.btnBorrarEquipo.TabIndex = 12;
            this.btnBorrarEquipo.Text = "Borrar";
            this.btnBorrarEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarEquipo.Click += new System.EventHandler(this.btnBorrarEquipo_Click);
            // 
            // btnModificarEquipo
            // 
            this.btnModificarEquipo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnModificarEquipo.Highlight = false;
            this.btnModificarEquipo.Location = new System.Drawing.Point(391, 366);
            this.btnModificarEquipo.Name = "btnModificarEquipo";
            this.btnModificarEquipo.Size = new System.Drawing.Size(180, 60);
            this.btnModificarEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnModificarEquipo.StyleManager = null;
            this.btnModificarEquipo.TabIndex = 11;
            this.btnModificarEquipo.Text = "Modificar";
            this.btnModificarEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnModificarEquipo.Click += new System.EventHandler(this.btnModificarEquipo_Click);
            // 
            // btnAgregarEquipo
            // 
            this.btnAgregarEquipo.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnAgregarEquipo.Highlight = false;
            this.btnAgregarEquipo.Location = new System.Drawing.Point(166, 366);
            this.btnAgregarEquipo.Name = "btnAgregarEquipo";
            this.btnAgregarEquipo.Size = new System.Drawing.Size(180, 60);
            this.btnAgregarEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarEquipo.StyleManager = null;
            this.btnAgregarEquipo.TabIndex = 10;
            this.btnAgregarEquipo.Text = "Agregar";
            this.btnAgregarEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarEquipo.Click += new System.EventHandler(this.btnAgregarEquipo_Click);
            // 
            // btnBuscarEquipo
            // 
            this.btnBuscarEquipo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBuscarEquipo.Highlight = false;
            this.btnBuscarEquipo.Location = new System.Drawing.Point(1004, 14);
            this.btnBuscarEquipo.Name = "btnBuscarEquipo";
            this.btnBuscarEquipo.Size = new System.Drawing.Size(140, 40);
            this.btnBuscarEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBuscarEquipo.StyleManager = null;
            this.btnBuscarEquipo.TabIndex = 9;
            this.btnBuscarEquipo.Text = "Buscar..";
            this.btnBuscarEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBuscarEquipo.Click += new System.EventHandler(this.btnBuscarProductos_Click);
            // 
            // tbBuscarEquipo
            // 
            this.tbBuscarEquipo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbBuscarEquipo.CustomBackground = false;
            this.tbBuscarEquipo.CustomForeColor = false;
            this.tbBuscarEquipo.FontSize = MetroFramework.MetroTextBoxSize.Small;
            this.tbBuscarEquipo.FontWeight = MetroFramework.MetroTextBoxWeight.Regular;
            this.tbBuscarEquipo.Location = new System.Drawing.Point(0, 14);
            this.tbBuscarEquipo.Multiline = false;
            this.tbBuscarEquipo.Name = "tbBuscarEquipo";
            this.tbBuscarEquipo.SelectedText = "";
            this.tbBuscarEquipo.Size = new System.Drawing.Size(998, 40);
            this.tbBuscarEquipo.Style = MetroFramework.MetroColorStyle.Blue;
            this.tbBuscarEquipo.StyleManager = null;
            this.tbBuscarEquipo.TabIndex = 8;
            this.tbBuscarEquipo.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tbBuscarEquipo.UseStyleColors = false;
            // 
            // dgvEquipo
            // 
            this.dgvEquipo.AllowUserToAddRows = false;
            this.dgvEquipo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEquipo.AutoGenerateColumns = false;
            this.dgvEquipo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvEquipo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvEquipo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.Honeydew;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEquipo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvEquipo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEquipo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.equipoIDDataGridViewTextBoxColumn,
            this.cuartoIDDataGridViewTextBoxColumn,
            this.nombreDataGridViewTextBoxColumn4,
            this.descripcionDataGridViewTextBoxColumn2});
            this.dgvEquipo.DataSource = this.equipoBindingSource;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvEquipo.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvEquipo.Location = new System.Drawing.Point(0, 65);
            this.dgvEquipo.Name = "dgvEquipo";
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvEquipo.RowsDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvEquipo.RowTemplate.Height = 60;
            this.dgvEquipo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEquipo.Size = new System.Drawing.Size(1144, 282);
            this.dgvEquipo.TabIndex = 3;
            this.dgvEquipo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvEquipo_CellContentClick);
            // 
            // equipoIDDataGridViewTextBoxColumn
            // 
            this.equipoIDDataGridViewTextBoxColumn.DataPropertyName = "EquipoID";
            this.equipoIDDataGridViewTextBoxColumn.HeaderText = "EquipoID";
            this.equipoIDDataGridViewTextBoxColumn.Name = "equipoIDDataGridViewTextBoxColumn";
            this.equipoIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.equipoIDDataGridViewTextBoxColumn.Visible = false;
            // 
            // cuartoIDDataGridViewTextBoxColumn
            // 
            this.cuartoIDDataGridViewTextBoxColumn.DataPropertyName = "CuartoID";
            this.cuartoIDDataGridViewTextBoxColumn.HeaderText = "Numero de Cuarto";
            this.cuartoIDDataGridViewTextBoxColumn.Name = "cuartoIDDataGridViewTextBoxColumn";
            this.cuartoIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn4
            // 
            this.nombreDataGridViewTextBoxColumn4.DataPropertyName = "Nombre";
            this.nombreDataGridViewTextBoxColumn4.HeaderText = "Nombre";
            this.nombreDataGridViewTextBoxColumn4.Name = "nombreDataGridViewTextBoxColumn4";
            this.nombreDataGridViewTextBoxColumn4.ReadOnly = true;
            this.nombreDataGridViewTextBoxColumn4.Width = 200;
            // 
            // descripcionDataGridViewTextBoxColumn2
            // 
            this.descripcionDataGridViewTextBoxColumn2.DataPropertyName = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn2.HeaderText = "Descripcion";
            this.descripcionDataGridViewTextBoxColumn2.Name = "descripcionDataGridViewTextBoxColumn2";
            this.descripcionDataGridViewTextBoxColumn2.ReadOnly = true;
            this.descripcionDataGridViewTextBoxColumn2.Width = 700;
            // 
            // equipoBindingSource
            // 
            this.equipoBindingSource.DataMember = "Equipo";
            this.equipoBindingSource.DataSource = this.lucySpaDB;
            this.equipoBindingSource.CurrentChanged += new System.EventHandler(this.equipoBindingSource_CurrentChanged);
            // 
            // tpConfiguraciones
            // 
            this.tpConfiguraciones.Controls.Add(this.btnBorrarUsuario);
            this.tpConfiguraciones.Controls.Add(this.btnAgregarUsuario);
            this.tpConfiguraciones.Controls.Add(this.dgvUsuarios);
            this.tpConfiguraciones.CustomBackground = false;
            this.tpConfiguraciones.HorizontalScrollbar = false;
            this.tpConfiguraciones.HorizontalScrollbarBarColor = true;
            this.tpConfiguraciones.HorizontalScrollbarHighlightOnWheel = false;
            this.tpConfiguraciones.HorizontalScrollbarSize = 10;
            this.tpConfiguraciones.Location = new System.Drawing.Point(4, 35);
            this.tpConfiguraciones.Name = "tpConfiguraciones";
            this.tpConfiguraciones.Size = new System.Drawing.Size(1179, 441);
            this.tpConfiguraciones.Style = MetroFramework.MetroColorStyle.Blue;
            this.tpConfiguraciones.StyleManager = null;
            this.tpConfiguraciones.TabIndex = 6;
            this.tpConfiguraciones.Text = "Configuraciones";
            this.tpConfiguraciones.Theme = MetroFramework.MetroThemeStyle.Light;
            this.tpConfiguraciones.VerticalScrollbar = false;
            this.tpConfiguraciones.VerticalScrollbarBarColor = true;
            this.tpConfiguraciones.VerticalScrollbarHighlightOnWheel = false;
            this.tpConfiguraciones.VerticalScrollbarSize = 10;
            this.tpConfiguraciones.Click += new System.EventHandler(this.tpConfiguraciones_Click_1);
            // 
            // btnBorrarUsuario
            // 
            this.btnBorrarUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBorrarUsuario.Highlight = false;
            this.btnBorrarUsuario.Location = new System.Drawing.Point(452, 129);
            this.btnBorrarUsuario.Name = "btnBorrarUsuario";
            this.btnBorrarUsuario.Size = new System.Drawing.Size(157, 52);
            this.btnBorrarUsuario.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnBorrarUsuario.StyleManager = null;
            this.btnBorrarUsuario.TabIndex = 6;
            this.btnBorrarUsuario.Text = "Borrar";
            this.btnBorrarUsuario.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnBorrarUsuario.Click += new System.EventHandler(this.btnBorrarUsuario_Click);
            // 
            // btnAgregarUsuario
            // 
            this.btnAgregarUsuario.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAgregarUsuario.Highlight = false;
            this.btnAgregarUsuario.Location = new System.Drawing.Point(452, 68);
            this.btnAgregarUsuario.Name = "btnAgregarUsuario";
            this.btnAgregarUsuario.Size = new System.Drawing.Size(157, 55);
            this.btnAgregarUsuario.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnAgregarUsuario.StyleManager = null;
            this.btnAgregarUsuario.TabIndex = 3;
            this.btnAgregarUsuario.Text = "Agregar Usuario";
            this.btnAgregarUsuario.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnAgregarUsuario.Click += new System.EventHandler(this.btnAgregarUsuario_Click_1);
            // 
            // dgvUsuarios
            // 
            this.dgvUsuarios.AllowUserToAddRows = false;
            this.dgvUsuarios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvUsuarios.AutoGenerateColumns = false;
            this.dgvUsuarios.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvUsuarios.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvUsuarios.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUsuarios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.usuarioIDDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1});
            this.dgvUsuarios.DataSource = this.usuariosBindingSource1;
            this.dgvUsuarios.Location = new System.Drawing.Point(29, 68);
            this.dgvUsuarios.Name = "dgvUsuarios";
            this.dgvUsuarios.ReadOnly = true;
            this.dgvUsuarios.RowHeadersWidth = 48;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvUsuarios.RowsDefaultCellStyle = dataGridViewCellStyle41;
            this.dgvUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvUsuarios.Size = new System.Drawing.Size(303, 200);
            this.dgvUsuarios.TabIndex = 2;
            // 
            // usuarioIDDataGridViewTextBoxColumn
            // 
            this.usuarioIDDataGridViewTextBoxColumn.DataPropertyName = "UsuarioID";
            this.usuarioIDDataGridViewTextBoxColumn.FillWeight = 120F;
            this.usuarioIDDataGridViewTextBoxColumn.HeaderText = "UsuarioID";
            this.usuarioIDDataGridViewTextBoxColumn.Name = "usuarioIDDataGridViewTextBoxColumn";
            this.usuarioIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.usuarioIDDataGridViewTextBoxColumn.Width = 150;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NuevoUsuario";
            this.dataGridViewTextBoxColumn1.HeaderText = "Usuario";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // usuariosBindingSource1
            // 
            this.usuariosBindingSource1.DataMember = "Usuarios";
            this.usuariosBindingSource1.DataSource = this.lucySpaDB;
            // 
            // btnLogin
            // 
            this.btnLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogin.Highlight = false;
            this.btnLogin.Location = new System.Drawing.Point(829, 48);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(115, 30);
            this.btnLogin.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnLogin.StyleManager = null;
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Iniciar Sesion";
            this.btnLogin.Theme = MetroFramework.MetroThemeStyle.Light;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click_1);
            // 
            // pbLogo
            // 
            this.pbLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbLogo.Image = global::LucySpa.Properties.Resources.lucyspa_logo;
            this.pbLogo.Location = new System.Drawing.Point(1028, 41);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(131, 69);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbLogo.TabIndex = 1;
            this.pbLogo.TabStop = false;
            // 
            // usuariosBindingSource
            // 
            this.usuariosBindingSource.DataMember = "Usuarios";
            this.usuariosBindingSource.DataSource = this.lucySpaDB;
            // 
            // clientesBindingSource
            // 
            this.clientesBindingSource.DataMember = "Clientes";
            this.clientesBindingSource.DataSource = this.lucySpaDB;
            // 
            // empleadosBindingSource
            // 
            this.empleadosBindingSource.DataMember = "Empleados";
            this.empleadosBindingSource.DataSource = this.lucySpaDB;
            // 
            // clientesTableAdapter
            // 
            this.clientesTableAdapter.ClearBeforeFill = true;
            // 
            // servicioTableAdapter
            // 
            this.servicioTableAdapter.ClearBeforeFill = true;
            // 
            // cuartoTableAdapter
            // 
            this.cuartoTableAdapter.ClearBeforeFill = true;
            // 
            // empleadosTableAdapter
            // 
            this.empleadosTableAdapter.ClearBeforeFill = true;
            // 
            // vistaCLienteTableAdapter
            // 
            this.vistaCLienteTableAdapter.ClearBeforeFill = true;
            // 
            // vistaEmpleadoTableAdapter
            // 
            this.vistaEmpleadoTableAdapter.ClearBeforeFill = true;
            // 
            // vistaCitasTableAdapter
            // 
            this.vistaCitasTableAdapter.ClearBeforeFill = true;
            // 
            // equipoTableAdapter
            // 
            this.equipoTableAdapter.ClearBeforeFill = true;
            // 
            // lucySpaDB1
            // 
            this.lucySpaDB1.DataSetName = "LucySpaDB";
            this.lucySpaDB1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tratamientoTableAdapter
            // 
            this.tratamientoTableAdapter.ClearBeforeFill = true;
            // 
            // productosTableAdapter
            // 
            this.productosTableAdapter.ClearBeforeFill = true;
            // 
            // usuariosTableAdapter
            // 
            this.usuariosTableAdapter.ClearBeforeFill = true;
            // 
            // tarjetasBindingSource
            // 
            this.tarjetasBindingSource.DataMember = "Tarjetas";
            this.tarjetasBindingSource.DataSource = this.dSTarjetas;
            // 
            // citasBindingSource
            // 
            this.citasBindingSource.DataMember = "Citas";
            this.citasBindingSource.DataSource = this.dSTarjetas;
            // 
            // citasTableAdapter
            // 
            this.citasTableAdapter.ClearBeforeFill = true;
            // 
            // tarjetasTableAdapter
            // 
            this.tarjetasTableAdapter.ClearBeforeFill = true;
            // 
            // ventaTarjetasBindingSource
            // 
            this.ventaTarjetasBindingSource.DataMember = "VentaTarjetas";
            this.ventaTarjetasBindingSource.DataSource = this.dSTarjetas;
            // 
            // ventaTarjetasTableAdapter
            // 
            this.ventaTarjetasTableAdapter.ClearBeforeFill = true;
            // 
            // vistaClientesConTarjetasTableAdapter
            // 
            this.vistaClientesConTarjetasTableAdapter.ClearBeforeFill = true;
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1206, 612);
            this.Controls.Add(this.pbLogo);
            this.Controls.Add(this.tcMenu);
            this.Controls.Add(this.btnLogin);
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "Inicio";
            this.Text = "LucySpa Software de Administración";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Inicio_Load);
            this.tcMenu.ResumeLayout(false);
            this.tpEmpleados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaEmpleadoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucySpaDB)).EndInit();
            this.tpServicios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServicios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.servicioBindingSource)).EndInit();
            this.tpTratamiento.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTratamiento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tratamientoBindingSource)).EndInit();
            this.tpClientes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaCLienteBindingSource)).EndInit();
            this.cmsClientes.ResumeLayout(false);
            this.tpCitas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCitas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaCitasBindingSource)).EndInit();
            this.tpAgenda.ResumeLayout(false);
            this.tpTarjetas.ResumeLayout(false);
            this.tpTarjetas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTarjetas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vistaClientesConTarjetasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dSTarjetas)).EndInit();
            this.tpProductos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productosBindingSource)).EndInit();
            this.tpCuartos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCuartos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cuartoBindingSource)).EndInit();
            this.tpEquipo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEquipo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipoBindingSource)).EndInit();
            this.tpConfiguraciones.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usuariosBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.usuariosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lucySpaDB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tarjetasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.citasBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ventaTarjetasBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl tcMenu;
        private MetroFramework.Controls.MetroTabPage tpClientes;
        private MetroFramework.Controls.MetroTabPage tpCitas;
        private MetroFramework.Controls.MetroTabPage tpEmpleados;
        private MetroFramework.Controls.MetroTabPage tpServicios;
        private MetroFramework.Controls.MetroButton btnAgregarCliente;
        private System.Windows.Forms.DataGridView dgvClientes;
        private MetroFramework.Controls.MetroButton btnAgregarEmpleado;
        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.DataGridView dgvCitas;
        private MetroFramework.Controls.MetroTextBox tbBuscarCita;
        private System.Windows.Forms.DataGridView dgvServicios;
        private MetroFramework.Controls.MetroButton btnGuardarEmpleado;
        private MetroFramework.Controls.MetroButton btnBorrarCliente;
        private MetroFramework.Controls.MetroButton btnModificarCliente;
        private MetroFramework.Controls.MetroTextBox tbBuscarCliente;
        private MetroFramework.Controls.MetroButton btnBorrarCita;
        private MetroFramework.Controls.MetroButton btnModificarCita;
        private MetroFramework.Controls.MetroButton btnBorrarEmpleado;
        private MetroFramework.Controls.MetroButton btnModificarEmpleado;
        private MetroFramework.Controls.MetroTextBox tbBuscarEmpleado;
        private MetroFramework.Controls.MetroTextBox tbBuscarServicio;
        private MetroFramework.Controls.MetroButton btnBorrarServicio;
        private MetroFramework.Controls.MetroButton btnModificarServicio;
        private MetroFramework.Controls.MetroTabPage tpTratamiento;
        private MetroFramework.Controls.MetroButton btnVender;
        private MetroFramework.Controls.MetroButton btnAgregarTratamiento;
        private System.Windows.Forms.DataGridView dgvTratamiento;
        private MetroFramework.Controls.MetroTabPage tpConfiguraciones;
        private MetroFramework.Controls.MetroTabPage tpTarjetas;
        private MetroFramework.Controls.MetroTabPage tpProductos;
        private MetroFramework.Controls.MetroButton btnBorrarTarjeta;
        private MetroFramework.Controls.MetroButton btnModificarCostoTarjeta;
        private MetroFramework.Controls.MetroTextBox tbBuscarTarjeta;
        private MetroFramework.Controls.MetroButton btnAgregarTarjeta;
        private System.Windows.Forms.DataGridView dgvTarjetas;
        private MetroFramework.Controls.MetroButton btnBorrarProductos;
        private MetroFramework.Controls.MetroButton btnModificarProductos;
        private MetroFramework.Controls.MetroTextBox tbBuscarProductos;
        private MetroFramework.Controls.MetroButton btnAgregarProductos;
        private System.Windows.Forms.DataGridView dgvProductos;
        private System.Windows.Forms.PictureBox pbLogo;
        private DataAccess.LucySpaDB lucySpaDB;
        private System.Windows.Forms.BindingSource clientesBindingSource;
        private DataAccess.LucySpaDBTableAdapters.ClientesTableAdapter clientesTableAdapter;
        //private System.Windows.Forms.DataGridViewImageColumn fotoDataGridViewImageColumn;
        private System.Windows.Forms.BindingSource servicioBindingSource;
        private DataAccess.LucySpaDBTableAdapters.ServicioTableAdapter servicioTableAdapter;
        ///private System.Windows.Forms.DataGridViewTextBoxColumn cuartoIDDataGridViewTextBoxColumn; Yo ivan Modifique esta linea y no se para que...
        private MetroFramework.Controls.MetroTabPage tpCuartos;
        private MetroFramework.Controls.MetroButton btnBorrarCuarto;
        private MetroFramework.Controls.MetroTextBox tbBuscarCuarto;
        private System.Windows.Forms.DataGridView dgvCuartos;
        private System.Windows.Forms.BindingSource cuartoBindingSource;
        private DataAccess.LucySpaDBTableAdapters.CuartoTableAdapter cuartoTableAdapter;
        private MetroFramework.Controls.MetroButton btnBuscar;
        private System.Windows.Forms.BindingSource empleadosBindingSource;
        private DataAccess.LucySpaDBTableAdapters.EmpleadosTableAdapter empleadosTableAdapter;
        //private System.Windows.Forms.DataGridViewImageColumn fotoDataGridViewImageColumn1;
        private System.Windows.Forms.BindingSource vistaCLienteBindingSource;
        private DataAccess.LucySpaDBTableAdapters.vistaCLienteTableAdapter vistaCLienteTableAdapter;
        private System.Windows.Forms.BindingSource vistaEmpleadoBindingSource;
        private DataAccess.LucySpaDBTableAdapters.vistaEmpleadoTableAdapter vistaEmpleadoTableAdapter;
        private MetroFramework.Controls.MetroButton btnNuevoCuarto;
        private MetroFramework.Controls.MetroButton btnAgendarCita;
        private System.Windows.Forms.BindingSource vistaCitasBindingSource;
        private DataAccess.LucySpaDBTableAdapters.vistaCitasTableAdapter vistaCitasTableAdapter;
        private MetroFramework.Controls.MetroButton btnBuscarEmpleado;
        private MetroFramework.Controls.MetroButton mbtnBuscarCita;
        private MetroFramework.Controls.MetroButton btnBuscarServicio;
        private MetroFramework.Controls.MetroButton btnBuscarTarjetas;
        private MetroFramework.Controls.MetroButton btnBuscarProducto;
        private MetroFramework.Controls.MetroButton btnBuscarCuarto;
        private MetroFramework.Controls.MetroTabPage tpAgenda;
        private System.Windows.Forms.Calendar.MonthView monthViewAgenda;
        private System.Windows.Forms.Calendar.Calendar calendarAgenda;
        private MetroFramework.Controls.MetroTabPage tpEquipo;
        private MetroFramework.Controls.MetroButton btnBuscarEquipo;
        private MetroFramework.Controls.MetroTextBox tbBuscarEquipo;
        private System.Windows.Forms.DataGridView dgvEquipo;
        private System.Windows.Forms.BindingSource equipoBindingSource;
        private DataAccess.LucySpaDBTableAdapters.EquipoTableAdapter equipoTableAdapter;
        private MetroFramework.Controls.MetroButton btnBorrarEquipo;
        private MetroFramework.Controls.MetroButton btnModificarEquipo;
        private MetroFramework.Controls.MetroButton btnAgregarEquipo;
        private MetroFramework.Controls.MetroButton btnModificar;
        private DataAccess.LucySpaDB lucySpaDB1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnaNumeroCuarto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnaNombreCuarto;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnaDescripcionCuarto;
        private MetroFramework.Controls.MetroButton btnRelacionCuartoServicios;
        private System.Windows.Forms.BindingSource tratamientoBindingSource;
        private DataAccess.LucySpaDBTableAdapters.TratamientoTableAdapter tratamientoTableAdapter;
        private MetroFramework.Controls.MetroButton btnBuscarTratamiento;
        private MetroFramework.Controls.MetroTextBox tbBsucarTratamiento;
        private MetroFramework.Controls.MetroButton btnDetalles;
        private MetroFramework.Controls.MetroButton btnmodificarTratamiento;
        private MetroFramework.Controls.MetroButton btnBorrar;
        private MetroFramework.Controls.MetroButton btnAsignarTarjeta;
        private DataAccess.DSTarjetas dSTarjetas;
        private System.Windows.Forms.BindingSource citasBindingSource;
        private DataAccess.DSTarjetasTableAdapters.CitasTableAdapter citasTableAdapter;
        private System.Windows.Forms.BindingSource tarjetasBindingSource;
        private DataAccess.DSTarjetasTableAdapters.TarjetasTableAdapter tarjetasTableAdapter;
        private System.Windows.Forms.BindingSource productosBindingSource;
        private DataAccess.LucySpaDBTableAdapters.ProductosTableAdapter productosTableAdapter;
        private MetroFramework.Controls.MetroButton btnVenderProducto;
        private MetroFramework.Controls.MetroButton btnReportes;
        private MetroFramework.Controls.MetroButton btnAdministrar;
        private System.Windows.Forms.DataGridViewTextBoxColumn citaIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClienteID;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomCompletoClie;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomCompletoEmp;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn NombreServicio;
        private System.Windows.Forms.DataGridViewTextBoxColumn costoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Realizado;
        private MetroFramework.Controls.MetroLabel lblTarjetasLibres;
        private MetroFramework.Controls.MetroLabel lblCantidadTarjetas;
        private MetroFramework.Controls.MetroLabel lblTarjetasAsignadas;
        private MetroFramework.Controls.MetroLabel lblCostoTarjeta;
        private MetroFramework.Controls.MetroTextBox tbNuevasTarjetas;
        private MetroFramework.Controls.MetroTextBox tbTarjetasLibres;
        private MetroFramework.Controls.MetroTextBox tbTarjetasAsignadas;
        private MetroFramework.Controls.MetroTextBox tbCantidadTarjetas;
        private MetroFramework.Controls.MetroTextBox tbCostoTarjetas;
        private MetroFramework.Controls.MetroLabel lblNuevaTarjetas;
        private System.Windows.Forms.BindingSource ventaTarjetasBindingSource;
        private DataAccess.DSTarjetasTableAdapters.VentaTarjetasTableAdapter ventaTarjetasTableAdapter;
        private System.Windows.Forms.BindingSource vistaClientesConTarjetasBindingSource;
        private DataAccess.DSTarjetasTableAdapters.VistaClientesConTarjetasTableAdapter vistaClientesConTarjetasTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tarjetaIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreCompletoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecchaCompraDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn precioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costoDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn cantidadDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn servicioIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn costoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empleadoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cumpleañosDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn direccionDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewImageColumn fotografiaEmppleado;
        private System.Windows.Forms.BindingSource usuariosBindingSource;
        private DataAccess.LucySpaDBTableAdapters.UsuariosTableAdapter usuariosTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn nuevoUsuarioDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroButton btnCancelarCita;
        private MetroFramework.Controls.MetroButton btnPagar;
        private MetroFramework.Controls.MetroButton btnLogin;
        private MetroFramework.Controls.MetroButton btnAgregarUsuario;
        private System.Windows.Forms.DataGridView dgvUsuarios;
        private System.Windows.Forms.BindingSource usuariosBindingSource1;
        private MetroFramework.Controls.MetroButton btnBorrarUsuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn usuarioIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clienteIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreCompleto;
        private System.Windows.Forms.DataGridViewTextBoxColumn cumpleañosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn direccionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefonoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn fotografiaCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn equipoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cuartoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn tratamientoIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn precioCatalogo;
        private System.Windows.Forms.ContextMenuStrip cmsClientes;
        private System.Windows.Forms.ToolStripMenuItem tratamientosVendidosToolStripMenuItem;
    }
}

